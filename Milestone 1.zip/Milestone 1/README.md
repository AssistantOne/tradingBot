# SOLOTREND X - AI-Based Trading Bot

## 🎯 Project Overview

SOLOTREND X is a confluence-based trading system that generates real-time Buy/Sell signals using advanced technical analysis and rule-based logic. This is **Milestone 1** focusing on signal generation and feature engineering.

## 📋 Strategy Components

### Core Features
- **Order Blocks (OB)**: Support/resistance zone detection
- **Supply and Demand Zones**: Price action-based zone identification
- **Hull Moving Average (HMA)**: Trend filtering with 21 and 50-period HMAs
- **Volume Shifts**: Volume spike detection and analysis
- **Session Filters**: NY and London session-only trading
- **Signal Types**: Potential, Strong, Super Buy/Sell signals
- **Risk Management**: Stop Loss, TP1, TP2, TP3 with configurable RR ratios

### Signal Generation Logic
1. **Trend Filter**: HMA trend direction must align with signal direction
2. **Session Filter**: Only trade during NY or London sessions
3. **Volume Filter**: Volume must be above average (1.2x minimum)
4. **Zone Proximity**: Price must be near valid Supply/Demand or Order Block zones
5. **Pattern Confirmation**: Bullish/Bearish candlestick patterns
6. **Strength Scoring**: Multiple confluence factors determine signal strength

## 🚀 Quick Start

### Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd Trading-Bot
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Run the main script**:
```bash
python main.py
```

### Basic Usage

```python
from solotrend_x import FeatureEngineer, SignalGenerator, Backtester, load_data

# Load data
df = load_data('your_data.csv', 'BTCUSD')

# Engineer features
fe = FeatureEngineer()
df_features = fe.engineer_features(df)

# Generate signals
sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
signals_df = sg.generate_signals(df_features)

# Run backtest
bt = Backtester(initial_capital=10000)
results = bt.run_backtest(df_features, signals_df)
bt.print_results(results)
```

## 📊 Features

### 1. Feature Engineering (`FeatureEngineer`)

**Technical Indicators**:
- Hull Moving Average (21, 50 periods)
- RSI, MACD, ADX
- ATR for volatility measurement
- Volume moving averages and ratios

**Pattern Detection**:
- Bullish/Bearish engulfing patterns
- Inside bars, Doji, Hammer patterns
- Supply/Demand zone detection
- Order block identification

**Session Indicators**:
- NY session (8:30 AM - 3:00 PM EST)
- London session (8:00 AM - 4:30 PM GMT)
- Session overlap detection

### 2. Signal Generation (`SignalGenerator`)

**Signal Types**:
- **Potential**: Basic confluence (score 1-4)
- **Strong**: Good confluence (score 5-7)
- **Super**: High confluence (score 8+)

**Confluence Factors**:
- Volume spikes (1-3 points)
- Trend strength (1-2 points)
- Pattern recognition (1-2 points)
- Session timing (1-2 points)
- RSI extremes (1 point)

**Risk Management**:
- Configurable RR ratios (default: 1.5, 2.5, 4.0)
- Dynamic stop loss placement
- Multiple take profit levels

### 3. Backtesting (`Backtester`)

**Performance Metrics**:
- Win rate and profit factor
- Average win/loss
- Maximum drawdown
- TP1/TP2/TP3 hit rates
- Signal strength analysis

**Output Files**:
- Detailed trade log (CSV)
- Equity curve and drawdown charts
- P&L distribution analysis
- Exit reason breakdown

## 📁 Project Structure

```
Trading Bot/
├── solotrend_x/
│   ├── __init__.py          # Package initialization
│   ├── utils.py             # Utility functions
│   ├── feature_engineer.py  # Feature engineering module
│   ├── signal_generator.py  # Signal generation logic
│   └── backtester.py        # Backtesting engine
├── main.py                  # Main execution script
├── requirements.txt         # Dependencies
├── README.md               # This file
└── outputs/                # Generated output files
    ├── signals_log.csv     # All generated signals
    ├── strong_signals.csv  # Strong+ signals only
    ├── backtest_trades.csv # Detailed trade log
    ├── price_signals.png   # Price chart with signals
    └── backtest_results.png # Performance charts
```

## 🔧 Configuration

### Signal Generator Parameters

```python
# Risk-reward ratios for TP1, TP2, TP3
risk_reward_ratios = [1.5, 2.5, 4.0]

# Minimum volume ratio for signal generation
min_volume_ratio = 1.2

# Price proximity to zones (1% default)
zone_proximity = 0.01

# Stop loss distance from zone (0.5% default)
sl_distance = 0.005
```

### Feature Engineering Parameters

```python
# HMA periods
hma_short = 21
hma_long = 50

# Volume spike threshold
volume_threshold = 2.0

# Order block parameters
min_touches = 3
price_tolerance = 0.002
```

## 📈 Sample Output

### Signal Example
```
Timestamp: 2024-01-15 14:30:00
Signal Type: Strong Buy
Entry Price: $45,250.00
Stop Loss: $44,987.50
TP1: $45,750.00 (RR: 1.5)
TP2: $46,500.00 (RR: 2.5)
TP3: $47,500.00 (RR: 4.0)
Confluence Factors: ['High Volume', 'Strong Trend', 'Demand Zone', 'NY Session']
```

### Backtest Results
```
📊 TRADE STATISTICS:
Total Trades: 45
Winning Trades: 28
Losing Trades: 17
Win Rate: 62.22%

💰 P&L ANALYSIS:
Total P&L: $2,450.50
Average Win: $180.25
Average Loss: -$95.30
Profit Factor: 2.75
Total Return: 24.51%

🎯 TAKE PROFIT ANALYSIS:
TP1 Hit Rate: 35.56% (16 hits)
TP2 Hit Rate: 20.00% (9 hits)
TP3 Hit Rate: 6.67% (3 hits)
Stop Loss Rate: 37.78% (17 hits)
```

## 🎯 Signal Strength Criteria

### Potential Signal (Score 1-4)
- Basic trend alignment
- Volume above average
- Near support/resistance
- Simple pattern recognition

### Strong Signal (Score 5-7)
- Good volume confirmation
- Strong trend (ADX > 20)
- Multiple pattern confluence
- Active trading session

### Super Signal (Score 8+)
- High volume spikes
- Very strong trend (ADX > 25)
- Multiple strong patterns
- Session overlap
- RSI extremes

## 🔮 Future Milestones

### Milestone 2 (Planned)
- Real-time data integration
- Telegram bot integration
- Web dashboard
- Advanced ML models

### Milestone 3 (Planned)
- Multi-timeframe analysis
- Portfolio management
- Risk management engine
- Live trading execution

## 📝 Data Format

The system accepts CSV files with the following columns:
- `datetime` or `Date`: Timestamp
- `open`: Opening price
- `high`: High price
- `low`: Low price
- `close`: Closing price
- `volume`: Trading volume

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ⚠️ Disclaimer

This software is for educational and research purposes only. Trading involves substantial risk of loss and is not suitable for all investors. Past performance does not guarantee future results. Always do your own research and consider consulting with a financial advisor before making investment decisions.

## 🆘 Support

For questions or issues:
1. Check the documentation
2. Review the example scripts
3. Open an issue on GitHub
4. Contact the development team

---

**SOLOTREND X** - Where AI Meets Trading Excellence 🚀 