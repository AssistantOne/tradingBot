"""
SOLOTREND X - AI-based Trading Bot
Milestone 1: Signal Generation and Feature Engineering

A confluence-based trading system using:
- Order Blocks (OB)
- Supply and Demand Zones  
- Hull Moving Average (HMA) trend filters
- Volume Shifts
- Session Filters (NY and London only)
- Signal Types: Potential, Strong, Super Buy/Sell
"""

__version__ = "1.0.0"
__author__ = "SOLOTREND X Team"

from .feature_engineer import FeatureEngineer
from .signal_generator import SignalGenerator
from .backtester import Backtester
from .utils import *

__all__ = [
    'FeatureEngineer',
    'SignalGenerator', 
    'Backtester',
    'load_data',
    'save_signals',
    'plot_signals'
] 