"""
Utility functions for SOLOTREND X trading bot
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to prevent popup windows
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, time
import warnings
warnings.filterwarnings('ignore')

def load_data(file_path, symbol='BTCUSD'):
    """
    Load OHLCV data from CSV file
    
    Args:
        file_path (str): Path to CSV file
        symbol (str): Symbol name for the data
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Try different common column formats
        df = pd.read_csv(file_path)
        
        # Standardize column names
        column_mapping = {
            'Date': 'datetime',
            'Time': 'datetime', 
            'Timestamp': 'datetime',
            'Open': 'open',
            'High': 'high',
            'Low': 'low',
            'Close': 'close',
            'Volume': 'volume',
            'Vol': 'volume'
        }
        
        df = df.rename(columns=column_mapping)
        
        # Ensure datetime column exists
        if 'datetime' not in df.columns:
            raise ValueError("No datetime column found in data")
            
        # Convert to datetime
        df['datetime'] = pd.to_datetime(df['datetime'])
        df = df.set_index('datetime')
        
        # Ensure required columns exist
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
            
        # Sort by datetime
        df = df.sort_index()
        
        # Add symbol column
        df['symbol'] = symbol
        
        print(f"Loaded {len(df)} candles for {symbol}")
        print(f"Date range: {df.index[0]} to {df.index[-1]}")
        
        return df
        
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def save_signals(signals_df, file_path='signals_log.csv'):
    """
    Save signals to CSV file
    
    Args:
        signals_df (pd.DataFrame): Signals dataframe
        file_path (str): Output file path
    """
    try:
        signals_df.to_csv(file_path, index=True)
        print(f"Signals saved to {file_path}")
    except Exception as e:
        print(f"Error saving signals: {e}")

def plot_signals(df, signals_df=None, save_path=None):
    """
    Plot price data with signals
    
    Args:
        df (pd.DataFrame): OHLCV data
        signals_df (pd.DataFrame): Signals data
        save_path (str): Path to save plot
    """
    plt.style.use('seaborn-v0_8')
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10), height_ratios=[3, 1])
    
    # Plot price data
    ax1.plot(df.index, df['close'], label='Close Price', alpha=0.7)
    
    # Plot HMA if available
    if 'hma_21' in df.columns:
        ax1.plot(df.index, df['hma_21'], label='HMA 21', alpha=0.8, linewidth=1.5)
    
    # Plot signals if available
    if signals_df is not None and len(signals_df) > 0:
        # Buy signals
        buy_signals = signals_df[signals_df['signal_type'].str.contains('Buy')]
        if len(buy_signals) > 0:
            ax1.scatter(buy_signals.index, buy_signals['entry_price'], 
                       color='green', marker='^', s=100, label='Buy Signals', zorder=5)
        
        # Sell signals  
        sell_signals = signals_df[signals_df['signal_type'].str.contains('Sell')]
        if len(sell_signals) > 0:
            ax1.scatter(sell_signals.index, sell_signals['entry_price'],
                       color='red', marker='v', s=100, label='Sell Signals', zorder=5)
    
    ax1.set_title('SOLOTREND X - Price Action & Signals', fontsize=14, fontweight='bold')
    ax1.set_ylabel('Price')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Plot volume
    ax2.bar(df.index, df['volume'], alpha=0.6, color='blue', label='Volume')
    ax2.set_ylabel('Volume')
    ax2.set_xlabel('Date')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.close()  # Close the figure to free memory

def get_session_info(dt):
    """
    Get session information for a given datetime
    
    Args:
        dt (datetime): Datetime object
        
    Returns:
        dict: Session information
    """
    # Define session times (UTC)
    ny_open = time(13, 30)  # 8:30 AM EST
    ny_close = time(20, 0)  # 3:00 PM EST
    
    london_open = time(8, 0)   # 8:00 AM GMT
    london_close = time(16, 30) # 4:30 PM GMT
    
    current_time = dt.time()
    
    # Check if in NY session
    ny_active = ny_open <= current_time <= ny_close
    
    # Check if in London session  
    london_active = london_open <= current_time <= london_close
    
    return {
        'ny_session': ny_active,
        'london_session': london_active,
        'active_session': ny_active or london_active
    }

def calculate_risk_reward_ratios(entry_price, stop_loss, tp1, tp2, tp3):
    """
    Calculate risk-reward ratios for a trade
    
    Args:
        entry_price (float): Entry price
        stop_loss (float): Stop loss price
        tp1, tp2, tp3 (float): Take profit levels
        
    Returns:
        dict: Risk-reward ratios
    """
    risk = abs(entry_price - stop_loss)
    
    rr1 = abs(tp1 - entry_price) / risk if risk > 0 else 0
    rr2 = abs(tp2 - entry_price) / risk if risk > 0 else 0
    rr3 = abs(tp3 - entry_price) / risk if risk > 0 else 0
    
    return {
        'rr1': round(rr1, 2),
        'rr2': round(rr2, 2), 
        'rr3': round(rr3, 2)
    } 