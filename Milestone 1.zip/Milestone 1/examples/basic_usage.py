"""
Basic Usage Example for SOLOTREND X
Demonstrates the core workflow with sample data
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solotrend_x import FeatureEngineer, SignalGenerator, Backtester, load_data, save_signals
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def create_sample_data():
    """Create sample OHLCV data for demonstration"""
    print("📊 Creating sample data...")
    
    # Generate 30 days of hourly data
    dates = pd.date_range(start='2024-01-01', periods=30*24, freq='H')
    
    # Create realistic price movements
    np.random.seed(123)
    base_price = 50000
    returns = np.random.normal(0, 0.015, len(dates))
    
    # Add trend
    trend = np.linspace(0, 0.2, len(dates))
    returns += trend / len(dates)
    
    prices = base_price * np.exp(np.cumsum(returns))
    
    # Generate OHLCV
    data = []
    for i, (date, price) in enumerate(zip(dates, prices)):
        volatility = 0.005
        open_price = price * (1 + np.random.normal(0, volatility))
        close_price = price * (1 + np.random.normal(0, volatility))
        high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, volatility/2)))
        low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, volatility/2)))
        
        volume = 1000000 * (1 + abs(returns[i]) * 5 + np.random.normal(0, 0.3))
        
        data.append({
            'datetime': date,
            'open': round(open_price, 2),
            'high': round(high_price, 2),
            'low': round(low_price, 2),
            'close': round(close_price, 2),
            'volume': round(volume, 0)
        })
    
    df = pd.DataFrame(data)
    df = df.set_index('datetime')
    df['symbol'] = 'BTCUSD'
    
    print(f"✅ Generated {len(df)} candles")
    return df

def main():
    """Main demonstration function"""
    print("🚀 SOLOTREND X - Basic Usage Example")
    print("=" * 50)
    
    # Step 1: Create sample data
    df = create_sample_data()
    
    # Step 2: Feature Engineering
    print("\n🔧 Step 2: Feature Engineering")
    print("-" * 30)
    
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    print(f"✅ Engineered {len(df_features.columns)} features")
    print(f"Feature columns: {list(df_features.columns[:10])}...")
    
    # Step 3: Signal Generation
    print("\n🎯 Step 3: Signal Generation")
    print("-" * 30)
    
    sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        print(f"✅ Generated {len(signals_df)} signals")
        
        # Show signal breakdown
        signal_counts = signals_df['signal_type'].value_counts()
        print("\nSignal Breakdown:")
        for signal_type, count in signal_counts.items():
            print(f"  {signal_type}: {count}")
        
        # Show sample signals
        print(f"\nSample Signals:")
        sample_cols = ['signal_type', 'entry_price', 'stop_loss', 'tp1', 'strength_score']
        print(signals_df[sample_cols].head())
        
        # Step 4: Backtesting
        print("\n📈 Step 4: Backtesting")
        print("-" * 30)
        
        bt = Backtester(initial_capital=10000)
        results = bt.run_backtest(df_features, signals_df, position_size=0.02)
        
        if results:
            # Print key results
            print(f"\n📊 Key Results:")
            print(f"Total Trades: {results['total_trades']}")
            print(f"Win Rate: {results['win_rate']}%")
            print(f"Total P&L: ${results['total_pnl']:,.2f}")
            print(f"Profit Factor: {results['profit_factor']}")
            print(f"Max Drawdown: {results['max_drawdown']}%")
            
            # Save results
            print("\n💾 Saving Results...")
            save_signals(signals_df, 'example_signals.csv')
            print("✅ Signals saved to 'example_signals.csv'")
            
        else:
            print("❌ No backtest results")
    
    else:
        print("❌ No signals generated")
        print("💡 Try adjusting parameters or using different data")

if __name__ == "__main__":
    main() 