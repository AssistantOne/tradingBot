"""
SOLOTREND X - Main Execution Script
Milestone 1: Signal Generation and Feature Engineering

This script demonstrates the complete workflow:
1. Load/Generate sample data
2. Engineer features
3. Generate signals
4. Run backtest
5. Save results and plots
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to prevent popup windows
import matplotlib.pyplot as plt
from binance.client import Client
import sys
import os

# Fix Unicode encoding issues on Windows
if sys.platform.startswith('win'):
    # Set UTF-8 encoding for stdout
    sys.stdout.reconfigure(encoding='utf-8')
    # Set environment variable for matplotlib
    os.environ['PYTHONIOENCODING'] = 'utf-8'

# Import SOLOTREND X modules
from solotrend_x import (
    FeatureEngineer, 
    SignalGenerator, 
    Backtester,
    load_data, 
    save_signals, 
    plot_signals
)

def generate_sample_data(symbol='BTCUSD', days=365, start_date=None):
    """
    Generate sample OHLCV data for testing
    
    Args:
        symbol (str): Symbol name
        days (int): Number of days of data
        start_date (datetime): Start date (default: 1 year ago)
        
    Returns:
        pd.DataFrame: Sample OHLCV data
    """
    if start_date is None:
        start_date = datetime.now() - timedelta(days=days)
    
    # Generate datetime index (hourly data)
    dates = pd.date_range(start=start_date, periods=days*24, freq='H')
    
    # Generate realistic price data with trends and volatility
    np.random.seed(42)  # For reproducible results
    
    # Base price
    base_price = 50000 if 'BTC' in symbol else 100
    
    # Generate price movements
    returns = np.random.normal(0, 0.02, len(dates))  # 2% daily volatility
    
    # Add some trend
    trend = np.linspace(0, 0.3, len(dates))  # 30% uptrend over period
    returns += trend / len(dates)
    
    # Add some mean reversion
    for i in range(1, len(returns)):
        returns[i] += -0.1 * returns[i-1]  # Mean reversion
    
    # Calculate prices
    prices = base_price * np.exp(np.cumsum(returns))
    
    # Generate OHLCV data
    data = []
    for i, (date, price) in enumerate(zip(dates, prices)):
        # Add some intraday volatility
        intraday_vol = np.random.normal(0, 0.005)
        
        open_price = price * (1 + intraday_vol)
        close_price = price * (1 + np.random.normal(0, 0.003))
        high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, 0.002)))
        low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, 0.002)))
        
        # Generate volume (higher during price movements)
        base_volume = 1000000
        volume_multiplier = 1 + abs(returns[i]) * 10
        volume = base_volume * volume_multiplier * (1 + np.random.normal(0, 0.3))
        
        data.append({
            'datetime': date,
            'open': round(open_price, 2),
            'high': round(high_price, 2),
            'low': round(low_price, 2),
            'close': round(close_price, 2),
            'volume': round(volume, 0)
        })
    
    df = pd.DataFrame(data)
    df = df.set_index('datetime')
    df['symbol'] = symbol
    
    print(f"Generated {len(df)} candles for {symbol}")
    print(f"Date range: {df.index[0]} to {df.index[-1]}")
    print(f"Price range: ${df['low'].min():.2f} - ${df['high'].max():.2f}")
    
    return df

def fetch_binance_ohlcv(symbol="BTCUSDT", interval="1h", start_str="1 Jan, 2023", end_str="1 Apr, 2023"):
    client = Client()
    klines = client.get_historical_klines(symbol, Client.KLINE_INTERVAL_1HOUR, start_str, end_str)
    df = pd.DataFrame(klines, columns=[
        'timestamp', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_asset_volume', 'number_of_trades',
        'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
    ])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
    df = df.astype({
        'open': 'float', 'high': 'float', 'low': 'float', 'close': 'float', 'volume': 'float'
    })
    return df

def main():
    """
    Main execution function
    """
    print("SOLOTREND X - Milestone 1")
    print("="*50)
    
    # Step 1: Load or generate data
    print("\nStep 1: Loading Data")
    print("-" * 30)

    # Always fetch from Binance
    df = fetch_binance_ohlcv(symbol="BTCUSDT", interval="1h", start_str="1 Jan, 2025", end_str="13 July, 2025")
    df['symbol'] = 'BTCUSD'
    
    # Step 2: Feature Engineering
    print("\nStep 2: Feature Engineering")
    print("-" * 30)
    
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    # Step 3: Signal Generation
    print("\nStep 3: Signal Generation")
    print("-" * 30)
    
    sg = SignalGenerator(risk_reward_ratios=[0.7, 0.9, 1.1])
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        # Filter signals by minimum strength
        strong_signals = sg.filter_signals(signals_df, min_strength='Super')
        
        print(f"\nSignal Summary:")
        print(f"Total signals: {len(signals_df)}")
        print(f"Strong+ signals: {len(strong_signals)}")
        
        # Display sample signals
        print(f"\nSample signals:")
        print(signals_df[['signal_type', 'entry_price', 'stop_loss', 'tp1', 'strength_score']].head())
        
        # Step 4: Backtesting
        print("\nStep 4: Backtesting")
        print("-" * 30)
        
        bt = Backtester(initial_capital=10000)
        results = bt.run_backtest(df_features, signals_df, position_size=0.02)
        
        if results:
            # Print results
            bt.print_results(results)
            
            # Step 5: Save Results
            print("\nStep 5: Saving Results")
            print("-" * 30)
            
            # Save signals to CSV
            save_signals(signals_df, 'outputs/signals_log.csv')
            
            # Save strong signals separately
            if len(strong_signals) > 0:
                save_signals(strong_signals, 'outputs/super_signals.csv')
            
            # Save backtest results
            if 'trades_df' in results:
                results['trades_df'].to_csv('outputs/backtest_trades.csv')
            
            # Step 6: Visualization
            print("\nStep 6: Visualization")
            print("-" * 30)
            
            # Plot price action with signals
            plot_signals(df_features, signals_df, 'outputs/price_signals.png')
            
            # Plot backtest results
            bt.plot_results(results, 'outputs/backtest_results.png')
            
            print("\nSOLOTREND X Milestone 1 completed successfully!")
            print("\nOutput files saved in 'outputs/' directory:")
            print("  - signals_log.csv: All generated signals")
            print("  - super_signals.csv: Strong and Super signals only")
            print("  - backtest_trades.csv: Detailed trade log")
            print("  - price_signals.png: Price chart with signals")
            print("  - backtest_results.png: Backtest performance charts")
            
        else:
            print("No signals generated for backtesting")
    
    else:
        print("No signals generated. Try adjusting parameters or using different data.")

def run_with_custom_data(file_path, symbol='BTCUSD'):
    """
    Run SOLOTREND X with custom data file
    
    Args:
        file_path (str): Path to CSV file
        symbol (str): Symbol name
    """
    print(f"Running SOLOTREND X with custom data: {file_path}")
    print("="*50)
    
    # Load data
    df = load_data(file_path, symbol)
    if df is None:
        print(f"Failed to load data from {file_path}")
        return
    
    # Run the complete pipeline
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    sg = SignalGenerator()
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        bt = Backtester()
        results = bt.run_backtest(df_features, signals_df)
        
        if results:
            bt.print_results(results)
            save_signals(signals_df, f'outputs/{symbol}_signals.csv')
            plot_signals(df_features, signals_df, f'outputs/{symbol}_chart.png')
            bt.plot_results(results, f'outputs/{symbol}_backtest.png')
    else:
        print("No signals generated from custom data")

if __name__ == "__main__":
    # Create outputs directory
    import os
    os.makedirs('outputs', exist_ok=True)
    
    # Run main function
    main()
    
    # Example of running with custom data (uncomment if you have data)
    # run_with_custom_data('path/to/your/data.csv', 'BTCUSD') 