"""
Trading Pairs Guide for SOLOTREND X
Complete guide to all available forex pairs, indices, and commodities
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

from main import fetch_data
from solotrend_x import FeatureEngineer, SignalGenerator, Backtester

# All available trading pairs
TRADING_PAIRS = {
    # FOREX PAIRS (Major & Minor)
    'forex_major': [
        'EUR/USD',    # Euro/US Dollar - Most liquid forex pair
        'GBP/USD',    # British Pound/US Dollar - Cable
        'USD/JPY',    # US Dollar/Japanese Yen - Most traded in Asia
        'USD/CHF',    # US Dollar/Swiss Franc - Swissy
        'AUD/USD',    # Australian Dollar/US Dollar - Aussie
        'USD/CAD',    # US Dollar/Canadian Dollar - Loonie
        'NZD/USD',    # New Zealand Dollar/US Dollar - Kiwi
    ],
    
    'forex_minor': [
        'EUR/GBP',    # Euro/British Pound - Chunnel
        'EUR/JPY',    # Euro/Japanese Yen - Euro-Yen
        'GBP/JPY',    # British Pound/Japanese Yen - Gopher
        'GBP/CHF',    # British Pound/Swiss Franc - Swissy
        'GBP/AUD',    # British Pound/Australian Dollar
        'AUD/JPY',    # Australian Dollar/Japanese Yen
        'NZD/JPY',    # New Zealand Dollar/Japanese Yen
        'CAD/JPY',    # Canadian Dollar/Japanese Yen
    ],
    
    # INDICES (Stock Market Indices)
    'indices': [
        'US30',       # Dow Jones Industrial Average
        'NAS100',     # NASDAQ-100 Index
        'SPX500',     # S&P 500 Index
        'GER30',      # DAX 30 (German Stock Index)
    ],
    
    # COMMODITIES
    'commodities': [
        'XAUUSD',     # Gold (XAU) vs US Dollar
    ]
}

def explain_trading_pairs():
    """
    Explain what each trading pair category is for
    """
    print("🎯 SOLOTREND X - Trading Pairs Guide")
    print("="*60)
    
    print("\n📊 FOREX PAIRS (Foreign Exchange)")
    print("-" * 40)
    print("Forex pairs represent the exchange rate between two currencies.")
    print("Example: EUR/USD = 1.0850 means 1 Euro = 1.0850 US Dollars")
    print()
    
    print("🔵 MAJOR PAIRS (Most Liquid):")
    for pair in TRADING_PAIRS['forex_major']:
        print(f"   • {pair}")
    print()
    
    print("🟡 MINOR PAIRS (Cross Rates):")
    for pair in TRADING_PAIRS['forex_minor']:
        print(f"   • {pair}")
    print()
    
    print("📈 INDICES (Stock Market Indices):")
    print("-" * 40)
    print("Indices represent the performance of a group of stocks.")
    print()
    for index in TRADING_PAIRS['indices']:
        if index == 'US30':
            print(f"   • {index} - Dow Jones Industrial Average (30 major US companies)")
        elif index == 'NAS100':
            print(f"   • {index} - NASDAQ-100 (100 largest non-financial companies)")
        elif index == 'SPX500':
            print(f"   • {index} - S&P 500 (500 largest US companies)")
        elif index == 'GER30':
            print(f"   • {index} - DAX 30 (30 largest German companies)")
    print()
    
    print("🥇 COMMODITIES:")
    print("-" * 40)
    print("Commodities are physical goods traded on markets.")
    print()
    for commodity in TRADING_PAIRS['commodities']:
        if commodity == 'XAUUSD':
            print(f"   • {commodity} - Gold vs US Dollar (Safe haven asset)")
    print()

def test_pair_availability():
    """
    Test which pairs are available with your Twelve Data API
    """
    print("🔍 Testing Pair Availability with Twelve Data")
    print("="*60)
    
    # Test a few pairs from each category
    test_pairs = [
        'EUR/USD',    # Major forex
        'GBP/JPY',    # Minor forex
        'US30',       # Index
        'XAUUSD',     # Commodity
    ]
    
    results = {}
    
    for pair in test_pairs:
        print(f"\nTesting {pair}...")
        try:
            # Fetch recent data
            df = fetch_data(
                provider="twelvedata",
                symbol=pair,
                interval="1h",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                results[pair] = {
                    'status': '✅ Available',
                    'data_points': len(df),
                    'price_range': f"{df['low'].min():.5f} - {df['high'].max():.5f}",
                    'latest_close': f"{df['close'].iloc[-1]:.5f}"
                }
                print(f"   ✅ Available - {len(df)} data points")
            else:
                results[pair] = {'status': '❌ No data'}
                print(f"   ❌ No data returned")
                
        except Exception as e:
            results[pair] = {'status': f'❌ Error: {str(e)[:50]}'}
            print(f"   ❌ Error: {e}")
    
    # Print summary
    print("\n" + "="*60)
    print("AVAILABILITY SUMMARY")
    print("="*60)
    
    for pair, result in results.items():
        if 'data_points' in result:
            print(f"{pair}: {result['status']} ({result['data_points']} points)")
        else:
            print(f"{pair}: {result['status']}")

def run_multi_pair_analysis():
    """
    Run analysis on multiple pairs to compare performance
    """
    print("\n📊 Multi-Pair Analysis")
    print("="*60)
    
    # Select pairs to analyze
    analysis_pairs = [
        'EUR/USD',    # Most liquid forex
        'GBP/USD',    # High volatility
        'USD/JPY',    # Asian session
        'XAUUSD',     # Safe haven
    ]
    
    results = {}
    
    for pair in analysis_pairs:
        print(f"\n🔍 Analyzing {pair}...")
        try:
            # Fetch data
            df = fetch_data(
                provider="twelvedata",
                symbol=pair,
                interval="1h",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Feature engineering
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Signal generation
                sg = SignalGenerator()
                signals_df = sg.generate_signals(df_features)
                
                if len(signals_df) > 0:
                    # Backtesting
                    bt = Backtester(initial_capital=10000)
                    backtest_results = bt.run_backtest(df_features, signals_df, position_size=0.02)
                    
                    if backtest_results:
                        results[pair] = {
                            'signals': len(signals_df),
                            'trades': backtest_results['total_trades'],
                            'win_rate': backtest_results['win_rate'],
                            'total_pnl': backtest_results['total_pnl'],
                            'profit_factor': backtest_results['profit_factor']
                        }
                        
                        print(f"   ✅ {len(signals_df)} signals, {backtest_results['total_trades']} trades")
                        print(f"   📈 Win Rate: {backtest_results['win_rate']:.1f}%, P&L: ${backtest_results['total_pnl']:,.0f}")
                    else:
                        print(f"   ⚠️ No backtest results")
                else:
                    print(f"   ⚠️ No signals generated")
            else:
                print(f"   ❌ No data available")
                
        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    # Print comparison
    if results:
        print("\n" + "="*60)
        print("PERFORMANCE COMPARISON")
        print("="*60)
        
        print(f"{'Pair':<10} {'Signals':<8} {'Trades':<8} {'Win Rate':<10} {'P&L':<12} {'Profit Factor':<12}")
        print("-" * 70)
        
        for pair, result in results.items():
            print(f"{pair:<10} {result['signals']:<8} {result['trades']:<8} {result['win_rate']:<10.1f}% ${result['total_pnl']:<11,.0f} {result['profit_factor']:<12.2f}")

def show_usage_examples():
    """
    Show practical examples of how to use different pairs
    """
    print("\n🎯 Usage Examples")
    print("="*60)
    
    print("\n1️⃣ FOREX TRADING STRATEGIES:")
    print("-" * 40)
    print("• EUR/USD: Best for beginners (high liquidity, tight spreads)")
    print("• GBP/USD: Good for volatility traders (larger price movements)")
    print("• USD/JPY: Ideal for Asian session trading")
    print("• AUD/USD: Great for commodity correlation trading")
    print()
    
    print("2️⃣ INDEX TRADING:")
    print("-" * 40)
    print("• US30: Trade the overall US market sentiment")
    print("• NAS100: Focus on technology sector performance")
    print("• SPX500: Broad market exposure")
    print("• GER30: European market opportunities")
    print()
    
    print("3️⃣ COMMODITY TRADING:")
    print("-" * 40)
    print("• XAUUSD: Hedge against inflation and market uncertainty")
    print("• Gold often moves opposite to USD strength")
    print("• Safe haven asset during market stress")
    print()
    
    print("4️⃣ PRACTICAL COMMANDS:")
    print("-" * 40)
    print("To trade EUR/USD:")
    print("   python main.py --symbol EUR/USD")
    print()
    print("To trade Gold:")
    print("   python main.py --symbol XAUUSD")
    print()
    print("To trade US30 index:")
    print("   python main.py --symbol US30")
    print()
    print("To test multiple pairs:")
    print("   python trading_pairs_guide.py --test-all")

def create_pair_config():
    """
    Create a configuration file for easy pair selection
    """
    config_content = """
# SOLOTREND X - Trading Pairs Configuration
# Copy this to config.py or use as environment variables

# Default trading pair (change this to your preferred pair)
DEFAULT_SYMBOL = "EUR/USD"

# Available pairs by category
FOREX_MAJOR_PAIRS = [
    "EUR/USD",    # Euro/US Dollar - Most liquid
    "GBP/USD",    # British Pound/US Dollar - High volatility
    "USD/JPY",    # US Dollar/Japanese Yen - Asian session
    "USD/CHF",    # US Dollar/Swiss Franc - Safe haven
    "AUD/USD",    # Australian Dollar/US Dollar - Commodity currency
    "USD/CAD",    # US Dollar/Canadian Dollar - Oil correlation
    "NZD/USD",    # New Zealand Dollar/US Dollar - Risk currency
]

FOREX_MINOR_PAIRS = [
    "EUR/GBP",    # Euro/British Pound - European focus
    "EUR/JPY",    # Euro/Japanese Yen - Euro-Asian
    "GBP/JPY",    # British Pound/Japanese Yen - High volatility
    "GBP/CHF",    # British Pound/Swiss Franc - European safe haven
    "GBP/AUD",    # British Pound/Australian Dollar - Risk sentiment
    "AUD/JPY",    # Australian Dollar/Japanese Yen - Carry trade
    "NZD/JPY",    # New Zealand Dollar/Japanese Yen - Carry trade
    "CAD/JPY",    # Canadian Dollar/Japanese Yen - Oil correlation
]

INDICES = [
    "US30",       # Dow Jones Industrial Average - US market
    "NAS100",     # NASDAQ-100 - Technology sector
    "SPX500",     # S&P 500 - Broad US market
    "GER30",      # DAX 30 - German market
]

COMMODITIES = [
    "XAUUSD",     # Gold vs US Dollar - Safe haven
]

# Trading session preferences
TRADING_SESSIONS = {
    "EUR/USD": ["london", "ny"],      # Best during London/NY overlap
    "GBP/USD": ["london", "ny"],      # High volatility during London
    "USD/JPY": ["tokyo", "london"],   # Best during Asian session
    "AUD/USD": ["sydney", "tokyo"],   # Best during Asian session
    "XAUUSD": ["london", "ny"],       # Best during major sessions
    "US30": ["ny"],                   # US market hours only
}

# Risk management by pair type
RISK_SETTINGS = {
    "forex_major": {"position_size": 0.02, "max_risk": 0.02},
    "forex_minor": {"position_size": 0.015, "max_risk": 0.015},
    "indices": {"position_size": 0.01, "max_risk": 0.01},
    "commodities": {"position_size": 0.01, "max_risk": 0.01},
}
"""
    
    with open('pair_config_example.py', 'w') as f:
        f.write(config_content)
    
    print("✅ Created pair_config_example.py with trading pair configurations")

if __name__ == "__main__":
    # Show the guide
    explain_trading_pairs()
    
    # Test availability
    test_pair_availability()
    
    # Show usage examples
    show_usage_examples()
    
    # Create config example
    create_pair_config()
    
    print("\n" + "="*60)
    print("🎯 NEXT STEPS")
    print("="*60)
    print("1. Test your preferred pairs with: python trading_pairs_guide.py")
    print("2. Run analysis on multiple pairs")
    print("3. Choose your favorite pair and start trading!")
    print("4. Check the generated pair_config_example.py for configurations")
    print("\n🚀 Your trading bot is ready for all these instruments!")
