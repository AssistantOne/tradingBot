from flask import Flask, render_template, jsonify, request, send_file, Response, stream_template
import subprocess
import os
import threading
import time
import json
import queue
from datetime import datetime
import glob

app = Flask(__name__)

# Global variables to track bot status and output
bot_running = False
bot_process = None
output_queue = queue.Queue()
bot_output = []
current_symbol = "EUR/USD"  # Default symbol

def run_bot(symbol="EUR/USD", session_filter=None, min_volume_ratio=None):
    """Run the main.py script in a separate thread and capture output"""
    global bot_running, bot_process, bot_output, current_symbol
    try:
        bot_output = []  # Clear previous output
        current_symbol = symbol
        
        # Set environment variables for proper encoding and symbol
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['TRADING_SYMBOL'] = symbol
        # Optional filters
        if session_filter:
            env['SESSION_FILTER'] = str(session_filter)
        if min_volume_ratio:
            env['MIN_VOLUME_RATIO_FILTER'] = str(min_volume_ratio)
        
        bot_process = subprocess.Popen(['python', 'main.py'], 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.STDOUT,
                                     text=True,
                                     bufsize=1,
                                     universal_newlines=True,
                                     encoding='utf-8',
                                     env=env)
        bot_running = True
        
        # Read output in real-time
        for line in iter(bot_process.stdout.readline, ''):
            if line:
                line = line.strip()
                # Add timestamp to the output
                timestamp = datetime.now().strftime('%H:%M:%S')
                timestamped_line = f"[{timestamp}] {line}"
                bot_output.append(timestamped_line)
                output_queue.put(timestamped_line)
                print(f"Bot output: {timestamped_line}")  # Debug print
        
        bot_process.stdout.close()
        bot_process.wait()
        
    except Exception as e:
        error_msg = f"Error running bot: {e}"
        timestamp = datetime.now().strftime('%H:%M:%S')
        timestamped_error = f"[{timestamp}] {error_msg}"
        bot_output.append(timestamped_error)
        output_queue.put(timestamped_error)
        print(timestamped_error)
    finally:
        bot_running = False
        bot_process = None

@app.route('/')
def index():
    """Main page with the web interface"""
    return render_template('index.html')

@app.route('/start', methods=['GET', 'POST'])
def start_bot():
    """Start the trading bot"""
    global bot_running, bot_output
    
    # Get the trading symbol from request
    symbol = "EUR/USD"  # Default
    session_filter = None
    min_volume_ratio = None
    if request.method == 'POST':
        try:
            data = request.get_json()
            if data and 'symbol' in data:
                symbol = data['symbol']
            if data and 'session_filter' in data:
                session_filter = data.get('session_filter') or None
            if data and 'min_volume_ratio' in data:
                min_volume_ratio = data.get('min_volume_ratio') or None
        except:
            pass  # Use default if JSON parsing fails
    
    if not bot_running:
        bot_output = []  # Clear previous output
        thread = threading.Thread(target=run_bot, args=(symbol, session_filter, min_volume_ratio))
        thread.daemon = True
        thread.start()
        return jsonify({'status': 'success', 'message': f'Bot started successfully with {symbol}'})
    else:
        return jsonify({'status': 'error', 'message': 'Bot is already running'})

@app.route('/stop')
def stop_bot():
    """Stop the trading bot"""
    global bot_running, bot_process
    if bot_running and bot_process:
        bot_process.terminate()
        bot_running = False
        return jsonify({'status': 'success', 'message': 'Bot stopped successfully'})
    else:
        return jsonify({'status': 'error', 'message': 'Bot is not running'})

@app.route('/output')
def get_bot_output():
    """Get the current bot output"""
    global bot_output
    return jsonify({
        'status': 'success',
        'output': bot_output,
        'bot_running': bot_running
    })

@app.route('/refresh')
def refresh_data():
    """Refresh the data and return current status"""
    global bot_running
    
    # Check if outputs exist
    outputs = {}
    
    # Check for CSV files
    csv_files = ['signals_log.csv', 'super_signals.csv', 'backtest_trades.csv']
    for csv_file in csv_files:
        file_path = os.path.join('outputs', csv_file)
        if os.path.exists(file_path):
            # Get file size and last modified time
            stat = os.stat(file_path)
            outputs[csv_file] = {
                'exists': True,
                'size': stat.st_size,
                'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            outputs[csv_file] = {'exists': False}
    
    # Check for image files
    image_files = ['price_signals.png', 'backtest_results.png']
    for img_file in image_files:
        file_path = os.path.join('outputs', img_file)
        if os.path.exists(file_path):
            stat = os.stat(file_path)
            outputs[img_file] = {
                'exists': True,
                'size': stat.st_size,
                'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            outputs[img_file] = {'exists': False}
    
    return jsonify({
        'status': 'success',
        'bot_running': bot_running,
        'outputs': outputs
    })

@app.route('/outputs/<filename>')
def get_output(filename):
    """Serve output files"""
    file_path = os.path.join('outputs', filename)
    if os.path.exists(file_path):
        return send_file(file_path)
    else:
        return jsonify({'error': 'File not found'}), 404

@app.route('/status')
def get_status():
    """Get current bot status"""
    global bot_running
    return jsonify({'bot_running': bot_running})

if __name__ == '__main__':
    # Create outputs directory if it doesn't exist
    os.makedirs('outputs', exist_ok=True)
    
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    
    app.run(debug=True, host='0.0.0.0', port=5000) 