# SOLOTREND X - Web Dashboard

A simple web interface for the SOLOTREND X trading bot.

## Features

- 🚀 **Start Bot**: Run the trading bot from the web interface
- 🛑 **Stop Bot**: Stop the running bot
- 🔄 **Refresh Data**: Update the display with latest outputs
- 📊 **Real-time Charts**: View generated charts and visualizations
- 📁 **File Downloads**: Download CSV files and results

## Installation

1. Install the required dependencies:
```bash
pip install -r requirements.txt
```

2. Make sure you have the `outputs` directory:
```bash
mkdir outputs
```

## Usage

1. Start the web server:
```bash
python app.py
```

2. Open your web browser and navigate to:
```
http://localhost:5000
```

3. Use the three buttons:
   - **Start Bot**: Click to run the trading bot
   - **Stop Bot**: Click to stop the running bot
   - **Refresh Data**: Click to update the display with latest outputs

## Interface

The web interface displays:
- **Trading Signals & Results**: CSV files with trading signals and backtest results
- **Charts & Visualizations**: PNG files showing price charts and backtest performance

## File Structure

```
├── app.py                 # Flask web application
├── templates/
│   └── index.html        # Web interface template
├── outputs/              # Generated outputs (created by main.py)
│   ├── signals_log.csv
│   ├── super_signals.csv
│   ├── backtest_trades.csv
│   ├── price_signals.png
│   └── backtest_results.png
└── main.py              # Original trading bot script
```

## Notes

- The web interface automatically refreshes every 30 seconds
- Charts and files are displayed as they become available
- The bot status is shown with a real-time indicator
- All outputs are served directly from the `outputs` directory 