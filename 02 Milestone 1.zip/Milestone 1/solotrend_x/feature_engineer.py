"""
Feature Engineering Module for SOLOTREND X
Extracts technical features from OHLCV data
"""

import pandas as pd
import numpy as np
from scipy import stats
# Removed 'import talib' as ta-lib is no longer used
from .utils import get_session_info

# Replace talib import with ta imports
from ta.trend import WMAIndicator, ADXIndicator, MACD
from ta.momentum import RSIIndicator
from ta.volatility import AverageTrueRange

class FeatureEngineer:
    """
    Feature engineering class for SOLOTREND X trading bot
    """
    
    def __init__(self, lookback_period=50):
        """
        Initialize feature engineer
        
        Args:
            lookback_period (int): Period for calculating rolling statistics
        """
        self.lookback_period = lookback_period
        
    def calculate_hma(self, df, period=21):
        """
        Calculate Hull Moving Average
        
        Args:
            df (pd.DataFrame): OHLCV data
            period (int): HMA period
            
        Returns:
            pd.Series: HMA values
        """
        # WMA = Weighted Moving Average using ta
        wma1 = WMAIndicator(close=df['close'], window=period // 2, fillna=True).wma()
        wma2 = WMAIndicator(close=df['close'], window=period, fillna=True).wma()
        
        # Raw HMA
        raw_hma = 2 * wma1 - wma2
        
        # Final HMA: WMA of raw_hma
        hma = WMAIndicator(close=raw_hma, window=int(np.sqrt(period)), fillna=True).wma()
        
        return hma
    
    def detect_volume_spikes(self, df, threshold=2.0):
        """
        Detect volume spikes using rolling statistics
        
        Args:
            df (pd.DataFrame): OHLCV data
            threshold (float): Multiplier for volume spike detection
            
        Returns:
            pd.Series: Volume spike indicator
        """
        volume_ma = df['volume'].rolling(window=20).mean()
        volume_std = df['volume'].rolling(window=20).std()
        
        # Volume spike when current volume > MA + threshold * std
        volume_spike = (df['volume'] > (volume_ma + threshold * volume_std)).astype(int)
        
        return volume_spike
    
    def find_order_blocks(self, df, min_touches=3, tolerance=0.002):
        """
        Find order block zones (support/resistance clusters)
        
        Args:
            df (pd.DataFrame): OHLCV data
            min_touches (int): Minimum touches to confirm zone
            tolerance (float): Price tolerance for zone identification
            
        Returns:
            dict: Order block zones
        """
        highs = df['high'].values
        lows = df['low'].values
        
        # Find swing highs and lows
        swing_highs = []
        swing_lows = []
        
        for i in range(2, len(df) - 2):
            # Swing high
            if highs[i] > highs[i-1] and highs[i] > highs[i-2] and \
               highs[i] > highs[i+1] and highs[i] > highs[i+2]:
                swing_highs.append((i, highs[i]))
            
            # Swing low
            if lows[i] < lows[i-1] and lows[i] < lows[i-2] and \
               lows[i] < lows[i+1] and lows[i] < lows[i+2]:
                swing_lows.append((i, lows[i]))
        
        # Group nearby levels
        resistance_zones = self._group_price_levels([h[1] for h in swing_highs], tolerance)
        support_zones = self._group_price_levels([l[1] for l in swing_lows], tolerance)
        
        # Filter zones with minimum touches
        resistance_zones = {k: v for k, v in resistance_zones.items() if len(v) >= min_touches}
        support_zones = {k: v for k, v in support_zones.items() if len(v) >= min_touches}
        
        return {
            'resistance': resistance_zones,
            'support': support_zones
        }
    
    def _group_price_levels(self, levels, tolerance):
        """
        Group nearby price levels
        
        Args:
            levels (list): List of price levels
            tolerance (float): Price tolerance
            
        Returns:
            dict: Grouped price levels
        """
        if not levels:
            return {}
            
        levels = sorted(levels)
        groups = {}
        current_group = [levels[0]]
        current_center = levels[0]
        
        for level in levels[1:]:
            if abs(level - current_center) / current_center <= tolerance:
                current_group.append(level)
                current_center = np.mean(current_group)
            else:
                if len(current_group) > 0:
                    groups[current_center] = current_group
                current_group = [level]
                current_center = level
        
        if len(current_group) > 0:
            groups[current_center] = current_group
            
        return groups
    
    def detect_supply_demand_zones(self, df, window=20):
        """
        Detect supply and demand zones using price action
        
        Args:
            df (pd.DataFrame): OHLCV data
            window (int): Window for zone detection
            
        Returns:
            pd.DataFrame: Supply/demand zone indicators
        """
        # Calculate price momentum
        df['price_momentum'] = df['close'].pct_change()
        
        # Supply zone: High volume + price rejection
        df['supply_zone'] = (
            (df['volume'] > df['volume'].rolling(window).mean() * 1.5) &
            (df['high'] - df['close'] > df['close'] - df['low']) &
            (df['close'] < df['open'])
        ).astype(int)
        
        # Demand zone: High volume + price acceptance
        df['demand_zone'] = (
            (df['volume'] > df['volume'].rolling(window).mean() * 1.5) &
            (df['close'] - df['low'] > df['high'] - df['close']) &
            (df['close'] > df['open'])
        ).astype(int)
        
        return df
    
    def detect_candle_patterns(self, df):
        """
        Detect candlestick patterns
        
        Args:
            df (pd.DataFrame): OHLCV data
            
        Returns:
            pd.DataFrame: Candle pattern indicators
        """
        # Engulfing patterns
        df['bullish_engulfing'] = (
            (df['close'] > df['open']) &
            (df['close'].shift(1) < df['open'].shift(1)) &
            (df['close'] > df['open'].shift(1)) &
            (df['open'] < df['close'].shift(1))
        ).astype(int)
        
        df['bearish_engulfing'] = (
            (df['close'] < df['open']) &
            (df['close'].shift(1) > df['open'].shift(1)) &
            (df['close'] < df['open'].shift(1)) &
            (df['open'] > df['close'].shift(1))
        ).astype(int)
        
        # Inside bars
        df['inside_bar'] = (
            (df['high'] <= df['high'].shift(1)) &
            (df['low'] >= df['low'].shift(1))
        ).astype(int)
        
        # Doji
        body_size = abs(df['close'] - df['open'])
        wick_size = df['high'] - df['low']
        df['doji'] = (body_size <= wick_size * 0.1).astype(int)
        
        # Hammer/Hanging Man
        body_size = abs(df['close'] - df['open'])
        lower_shadow = np.minimum(df['open'], df['close']) - df['low']
        upper_shadow = df['high'] - np.maximum(df['open'], df['close'])
        
        df['hammer'] = (
            (lower_shadow > body_size * 2) &
            (upper_shadow < body_size * 0.5)
        ).astype(int)
        
        return df
    
    def add_session_indicators(self, df):
        """
        Add session time indicators
        
        Args:
            df (pd.DataFrame): OHLCV data
            
        Returns:
            pd.DataFrame: Data with session indicators
        """
        df['ny_session'] = 0
        df['london_session'] = 0
        df['active_session'] = 0
        
        for i, dt in enumerate(df.index):
            session_info = get_session_info(dt)
            df.iloc[i, df.columns.get_loc('ny_session')] = session_info['ny_session']
            df.iloc[i, df.columns.get_loc('london_session')] = session_info['london_session']
            df.iloc[i, df.columns.get_loc('active_session')] = session_info['active_session']
        
        return df
    
    def calculate_trend_strength(self, df, period=14):
        """
        Calculate trend strength using ADX
        
        Args:
            df (pd.DataFrame): OHLCV data
            period (int): ADX period
            
        Returns:
            pd.Series: Trend strength values
        """
        adx = ADXIndicator(high=df['high'], low=df['low'], close=df['close'], window=period, fillna=True).adx()
        return adx
    
    def engineer_features(self, df):
        """
        Main feature engineering function
        
        Args:
            df (pd.DataFrame): OHLCV data
            
        Returns:
            pd.DataFrame: Data with engineered features
        """
        print("Engineering features...")
        
        # Make a copy to avoid modifying original
        df_features = df.copy()
        
        # Basic technical indicators
        df_features['hma_21'] = self.calculate_hma(df_features, 21)
        df_features['hma_50'] = self.calculate_hma(df_features, 50)
        
        # Volume features
        df_features['volume_spike'] = self.detect_volume_spikes(df_features)
        df_features['volume_ma'] = df_features['volume'].rolling(window=20).mean()
        df_features['volume_ratio'] = df_features['volume'] / df_features['volume_ma']
        
        # Price action features
        df_features['price_range'] = df_features['high'] - df_features['low']
        df_features['body_size'] = abs(df_features['close'] - df_features['open'])
        df_features['upper_shadow'] = df_features['high'] - np.maximum(df_features['open'], df_features['close'])
        df_features['lower_shadow'] = np.minimum(df_features['open'], df_features['close']) - df_features['low']
        
        # Momentum indicators
        df_features['rsi'] = RSIIndicator(close=df_features['close'], window=14, fillna=True).rsi()
        macd = MACD(close=df_features['close'], fillna=True)
        df_features['macd'] = macd.macd()
        df_features['macd_signal'] = macd.macd_signal()
        df_features['macd_hist'] = macd.macd_diff()
        
        # Trend strength
        df_features['adx'] = self.calculate_trend_strength(df_features)
        
        # Supply/Demand zones
        df_features = self.detect_supply_demand_zones(df_features)
        
        # Candle patterns
        df_features = self.detect_candle_patterns(df_features)
        
        # Session indicators
        df_features = self.add_session_indicators(df_features)
        
        # Trend direction
        df_features['hma_trend'] = np.where(df_features['hma_21'] > df_features['hma_50'], 1, -1)
        df_features['price_above_hma'] = (df_features['close'] > df_features['hma_21']).astype(int)
        
        # Volatility
        df_features['atr'] = AverageTrueRange(high=df_features['high'], low=df_features['low'], close=df_features['close'], window=14, fillna=True).average_true_range()
        df_features['volatility'] = df_features['atr'] / df_features['close']
        
        # Clean up NaN values
        df_features = df_features.fillna(method='ffill').fillna(0)
        
        print(f"Engineered {len(df_features.columns)} features")
        
        return df_features 