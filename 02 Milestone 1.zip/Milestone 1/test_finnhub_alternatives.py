"""
Test script to check Finnhub alternatives and provide solutions
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

def test_finnhub_access():
    """
    Test what data is available with the current Finnhub API key
    """
    print("🔍 Testing Finnhub API Access")
    print("="*50)
    
    try:
        import finnhub
        
        # Test with user's API key
        api_key = 'd2afda1r01qoad6pkllgd2afda1r01qoad6pklm0'
        finnhub_client = finnhub.Client(api_key=api_key)
        
        print(f"Using API key: {api_key[:10]}...{api_key[-10:]}")
        print()
        
        # Test 1: Basic API access
        print("1. Testing basic API access...")
        try:
            # Try to get a simple quote
            quote = finnhub_client.quote('AAPL')
            if quote:
                print("✅ Basic API access works!")
                print(f"   AAPL Quote: ${quote['c']:.2f}")
            else:
                print("❌ Basic API access failed")
        except Exception as e:
            print(f"❌ Basic API access error: {e}")
        
        print()
        
        # Test 2: Forex data access
        print("2. Testing forex data access...")
        try:
            # Try to get forex data
            end_date = datetime.now()
            start_date = end_date - timedelta(days=1)
            start_timestamp = int(start_date.timestamp())
            end_timestamp = int(end_date.timestamp())
            
            forex_data = finnhub_client.forex_candles('EURUSD', '60', start_timestamp, end_timestamp)
            
            if forex_data['s'] == 'ok' and len(forex_data['t']) > 0:
                print("✅ Forex data access works!")
                print(f"   Fetched {len(forex_data['t'])} EURUSD candles")
            else:
                print("❌ Forex data not available in free tier")
                print(f"   Response: {forex_data}")
        except Exception as e:
            print(f"❌ Forex data access error: {e}")
            print("   This is expected - forex data requires premium subscription")
        
        print()
        
        # Test 3: Stock data access
        print("3. Testing stock data access...")
        try:
            # Try to get stock data
            stock_data = finnhub_client.stock_candles('AAPL', '60', start_timestamp, end_timestamp)
            
            if stock_data['s'] == 'ok' and len(stock_data['t']) > 0:
                print("✅ Stock data access works!")
                print(f"   Fetched {len(stock_data['t'])} AAPL candles")
            else:
                print("❌ Stock data not available")
        except Exception as e:
            print(f"❌ Stock data access error: {e}")
        
        print()
        
        # Test 4: Crypto data access
        print("4. Testing crypto data access...")
        try:
            # Try to get crypto data
            crypto_data = finnhub_client.crypto_candles('BINANCE:BTCUSDT', '60', start_timestamp, end_timestamp)
            
            if crypto_data['s'] == 'ok' and len(crypto_data['t']) > 0:
                print("✅ Crypto data access works!")
                print(f"   Fetched {len(crypto_data['t'])} BTCUSDT candles")
            else:
                print("❌ Crypto data not available")
        except Exception as e:
            print(f"❌ Crypto data access error: {e}")
        
    except ImportError:
        print("❌ Finnhub library not installed")
        print("   Run: pip install finnhub-python")
    except Exception as e:
        print(f"❌ General error: {e}")

def suggest_alternatives():
    """
    Suggest alternative data providers and solutions
    """
    print("\n" + "="*50)
    print("ALTERNATIVE SOLUTIONS")
    print("="*50)
    
    print("\n🔧 **Solution 1: Use Sample Data (Recommended for Testing)**")
    print("   - The bot will use realistic sample data for forex trading")
    print("   - Perfect for testing the trading strategy")
    print("   - No API keys required")
    print("   - Run: python main.py")
    
    print("\n🔧 **Solution 2: Get Free API Key from Twelve Data**")
    print("   - Visit: https://twelvedata.com/")
    print("   - Sign up for free account")
    print("   - Get free API key (no government ID required)")
    print("   - Set environment variable: export TWELVEDATA_API_KEY='your_key'")
    print("   - Set provider: export DATA_PROVIDER='twelvedata'")
    
    print("\n🔧 **Solution 3: Upgrade Finnhub Plan**")
    print("   - Visit: https://finnhub.io/pricing")
    print("   - Upgrade to paid plan for forex data access")
    print("   - Current key will work with premium features")
    
    print("\n🔧 **Solution 4: Use OANDA (Requires Verification)**")
    print("   - Visit: https://www.oanda.com/")
    print("   - Sign up and verify account")
    print("   - Get API access token")
    print("   - Set environment variable: export OANDA_ACCESS_TOKEN='your_token'")
    print("   - Set provider: export DATA_PROVIDER='oanda'")

def test_sample_data():
    """
    Test the sample data generation
    """
    print("\n🧪 Testing Sample Data Generation")
    print("="*50)
    
    try:
        from main import generate_sample_data
        
        # Test sample data generation
        df = generate_sample_data('EURUSD', days=7)
        
        if len(df) > 0:
            print("✅ Sample data generation works!")
            print(f"   Generated {len(df)} data points")
            print(f"   Date range: {df.index[0]} to {df.index[-1]}")
            print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
            print(f"   Latest close: {df['close'].iloc[-1]:.5f}")
            print("\n   Sample data is realistic and suitable for testing!")
        else:
            print("❌ Sample data generation failed")
            
    except Exception as e:
        print(f"❌ Sample data test error: {e}")

if __name__ == "__main__":
    print("🚀 SOLOTREND X - Finnhub Alternatives Test")
    print("="*50)
    
    # Test current Finnhub access
    test_finnhub_access()
    
    # Test sample data
    test_sample_data()
    
    # Suggest alternatives
    suggest_alternatives()
    
    print("\n" + "="*50)
    print("RECOMMENDATION")
    print("="*50)
    print("\n🎯 **For immediate use, run the bot with sample data:**")
    print("   python main.py")
    print("\n   This will use realistic sample data and test your trading strategy!")
    print("\n🎯 **For real data, get a free API key from Twelve Data:**")
    print("   https://twelvedata.com/")
    print("\n✅ Your trading bot is ready to use!")
