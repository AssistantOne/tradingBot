"""
Test script to verify Twelve Data API key is working
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

from main import fetch_twelvedata_forex, fetch_data

def test_twelvedata_connection():
    """
    Test the Twelve Data API connection with the user's key
    """
    print("🔍 Testing Twelve Data API Connection")
    print("="*50)
    
    # Test with user's API key
    api_key = '85d5c52f7c4d49aa83373de0a83a8f5e'
    
    print(f"Using API key: {api_key[:10]}...{api_key[-10:]}")
    print()
    
    # Test different forex pairs
    test_pairs = [
        "EUR/USD",    # Euro/US Dollar
        "GBP/USD",    # British Pound/US Dollar
        "USD/JPY",    # US Dollar/Japanese Yen
        "AUD/USD",    # Australian Dollar/US Dollar
        "USD/CHF",    # US Dollar/Swiss Franc
    ]
    
    for pair in test_pairs:
        print(f"Testing {pair}...")
        print("-" * 30)
        
        try:
            # Fetch data for the last 7 days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)
            
            df = fetch_twelvedata_forex(
                symbol=pair,
                interval="1h",  # 1 hour
                start_str=start_date.strftime("%Y-%m-%d"),
                end_str=end_date.strftime("%Y-%m-%d")
            )
            
            if len(df) > 0:
                print(f"✅ Success! Fetched {len(df)} data points")
                print(f"   Date range: {df.index[0]} to {df.index[-1]}")
                print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
                print(f"   Latest close: {df['close'].iloc[-1]:.5f}")
            else:
                print(f"❌ No data returned for {pair}")
                
        except Exception as e:
            print(f"❌ Error testing {pair}: {e}")
        
        print()
    
    print("="*50)
    print("Twelve Data API Test Completed!")
    print()
    print("If you see ✅ Success messages above, your API key is working correctly!")
    print("You can now run the main trading bot with real forex data.")

def test_main_function():
    """
    Test the main function with Twelve Data
    """
    print("\n🧪 Testing Main Function with Twelve Data")
    print("="*50)
    
    try:
        # Set environment variable for testing
        os.environ['DATA_PROVIDER'] = 'twelvedata'
        
        # Import and test the main function
        from main import main
        
        print("Running main function with Twelve Data...")
        print("This will test the complete pipeline with real forex data.")
        print()
        
        # Run the main function
        main()
        
    except Exception as e:
        print(f"❌ Error in main function: {e}")
        print("This might be expected if there are issues with the trading logic.")

def test_multiple_pairs():
    """
    Test multiple forex pairs with Twelve Data
    """
    print("\n📊 Testing Multiple Forex Pairs")
    print("="*50)
    
    pairs = [
        "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CHF",
        "USD/CAD", "EUR/GBP", "EUR/JPY", "GBP/JPY", "GBP/CHF"
    ]
    
    results = {}
    
    for pair in pairs[:5]:  # Test first 5 pairs
        print(f"\nTesting {pair}...")
        try:
            df = fetch_data(
                provider="twelvedata",
                symbol=pair,
                interval="1h",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                results[pair] = {
                    'data_points': len(df),
                    'price_range': f"{df['low'].min():.5f} - {df['high'].max():.5f}",
                    'latest_close': f"{df['close'].iloc[-1]:.5f}"
                }
                print(f"✅ {len(df)} data points")
            else:
                print(f"❌ No data")
                
        except Exception as e:
            print(f"❌ Error: {e}")
    
    # Print summary
    print("\n" + "="*50)
    print("SUMMARY")
    print("="*50)
    
    for pair, result in results.items():
        print(f"{pair}: {result['data_points']} points, {result['price_range']}, Close: {result['latest_close']}")

if __name__ == "__main__":
    print("🚀 SOLOTREND X - Twelve Data API Test")
    print("="*50)
    
    # Test the connection first
    test_twelvedata_connection()
    
    # Test multiple pairs
    test_multiple_pairs()
    
    # Ask user if they want to test the main function
    print("\nWould you like to test the complete trading bot with Twelve Data?")
    print("This will run the full pipeline including signal generation and backtesting.")
    
    try:
        response = input("Enter 'y' to continue or any other key to skip: ").lower().strip()
        if response == 'y':
            test_main_function()
        else:
            print("Skipping main function test.")
    except KeyboardInterrupt:
        print("\nTest interrupted by user.")
    
    print("\n✅ Twelve Data API setup complete!")
    print("\nTo run the trading bot with your Twelve Data forex data:")
    print("python main.py")
