
# SOLOTREND X - Trading Pairs Configuration
# Copy this to config.py or use as environment variables

# Default trading pair (change this to your preferred pair)
DEFAULT_SYMBOL = "EUR/USD"

# Available pairs by category
FOREX_MAJOR_PAIRS = [
    "EUR/USD",    # Euro/US Dollar - Most liquid
    "GBP/USD",    # British Pound/US Dollar - High volatility
    "USD/JPY",    # US Dollar/Japanese Yen - Asian session
    "USD/CHF",    # US Dollar/Swiss Franc - Safe haven
    "AUD/USD",    # Australian Dollar/US Dollar - Commodity currency
    "USD/CAD",    # US Dollar/Canadian Dollar - Oil correlation
    "NZD/USD",    # New Zealand Dollar/US Dollar - Risk currency
]

FOREX_MINOR_PAIRS = [
    "EUR/GBP",    # Euro/British Pound - European focus
    "EUR/JPY",    # Euro/Japanese Yen - Euro-Asian
    "GBP/JPY",    # British Pound/Japanese Yen - High volatility
    "GBP/CHF",    # British Pound/Swiss Franc - European safe haven
    "GBP/AUD",    # British Pound/Australian Dollar - Risk sentiment
    "AUD/JPY",    # Australian Dollar/Japanese Yen - Carry trade
    "NZD/JPY",    # New Zealand Dollar/Japanese Yen - Carry trade
    "CAD/JPY",    # Canadian Dollar/Japanese Yen - Oil correlation
]

INDICES = [
    "US30",       # Dow Jones Industrial Average - US market
    "NAS100",     # NASDAQ-100 - Technology sector
    "SPX500",     # S&P 500 - Broad US market
    "GER30",      # DAX 30 - German market
]

COMMODITIES = [
    "XAUUSD",     # Gold vs US Dollar - Safe haven
]

# Trading session preferences
TRADING_SESSIONS = {
    "EUR/USD": ["london", "ny"],      # Best during London/NY overlap
    "GBP/USD": ["london", "ny"],      # High volatility during London
    "USD/JPY": ["tokyo", "london"],   # Best during Asian session
    "AUD/USD": ["sydney", "tokyo"],   # Best during Asian session
    "XAUUSD": ["london", "ny"],       # Best during major sessions
    "US30": ["ny"],                   # US market hours only
}

# Risk management by pair type
RISK_SETTINGS = {
    "forex_major": {"position_size": 0.02, "max_risk": 0.02},
    "forex_minor": {"position_size": 0.015, "max_risk": 0.015},
    "indices": {"position_size": 0.01, "max_risk": 0.01},
    "commodities": {"position_size": 0.01, "max_risk": 0.01},
}
