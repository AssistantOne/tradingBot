"""
SOLOTREND X - Main Execution Script
Milestone 1: Signal Generation and Feature Engineering

This script demonstrates the complete workflow:
1. Load/Generate sample data
2. Engineer features
3. Generate signals
4. Run backtest
5. Save results and plots
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to prevent popup windows
import matplotlib.pyplot as plt
from oandapyV20 import API
from oandapyV20.endpoints.instruments import InstrumentsCandles
import finnhub
import requests
import sys
import os
import re
import config as cfg

# Fix Unicode encoding issues on Windows
if sys.platform.startswith('win'):
    # Set UTF-8 encoding for stdout
    sys.stdout.reconfigure(encoding='utf-8')
    # Set environment variable for matplotlib
    os.environ['PYTHONIOENCODING'] = 'utf-8'

# Import SOLOTREND X modules
from solotrend_x import (
    FeatureEngineer, 
    SignalGenerator, 
    Backtester,
    load_data, 
    save_signals, 
    plot_signals
)

def generate_sample_data(symbol='EUR_USD', days=365, start_date=None):
    """
    Generate sample OHLCV data for testing
    
    Args:
        symbol (str): Symbol name
        days (int): Number of days of data
        start_date (datetime): Start date (default: 1 year ago)
        
    Returns:
        pd.DataFrame: Sample OHLCV data
    """
    if start_date is None:
        start_date = datetime.now() - timedelta(days=days)
    
    # Generate datetime index (hourly data)
    dates = pd.date_range(start=start_date, periods=days*24, freq='H')
    
    # Generate realistic price data with trends and volatility
    np.random.seed(42)  # For reproducible results
    
    # Base price (typical forex prices)
    base_price = 1.1000 if 'EUR_USD' in symbol else 1.2500
    
    # Generate price movements
    returns = np.random.normal(0, 0.001, len(dates))  # 0.1% hourly volatility
    
    # Add some trend
    trend = np.linspace(0, 0.05, len(dates))  # 5% trend over period
    returns += trend / len(dates)
    
    # Add some mean reversion
    for i in range(1, len(returns)):
        returns[i] += -0.1 * returns[i-1]  # Mean reversion
    
    # Calculate prices
    prices = base_price * np.exp(np.cumsum(returns))
    
    # Generate OHLCV data
    data = []
    for i, (date, price) in enumerate(zip(dates, prices)):
        # Add some intraday volatility
        intraday_vol = np.random.normal(0, 0.0005)
        
        open_price = price * (1 + intraday_vol)
        close_price = price * (1 + np.random.normal(0, 0.0003))
        high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, 0.0002)))
        low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, 0.0002)))
        
        # Generate volume (higher during price movements)
        base_volume = 1000000
        volume_multiplier = 1 + abs(returns[i]) * 100
        volume = base_volume * volume_multiplier * (1 + np.random.normal(0, 0.3))
        
        data.append({
            'datetime': date,
            'open': round(open_price, 5),
            'high': round(high_price, 5),
            'low': round(low_price, 5),
            'close': round(close_price, 5),
            'volume': round(volume, 0)
        })
    
    df = pd.DataFrame(data)
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime')
    df['symbol'] = symbol
    
    return df

def _detect_instrument_type(raw_symbol: str) -> str:
    """
    Classify the given symbol as 'forex', 'index', or 'commodity'.
    """
    symbol = raw_symbol.upper().replace(" ", "")
    index_symbols = {"US30", "NAS100", "SPX500", "GER30"}
    # Include common index tickers and proxies for detection
    index_aliases = {
        "DJI", "^DJI",  # Dow Jones
        "NDX", "^NDX",  # NASDAQ-100
        "SPX", "^GSPC", # S&P 500
        "DAX", "^GDAXI",# DAX
        # ETF proxies
        "QQQ", "SPY", "EWG"
    }
    commodity_symbols = {"XAUUSD", "XAU/USD", "XAU_USD"}

    if symbol in index_symbols or symbol in index_aliases:
        return "index"
    if symbol in commodity_symbols:
        return "commodity"

    # Heuristic: 6-letter, or with slash/underscore looks like forex
    if re.fullmatch(r"[A-Z]{6}", symbol) or re.fullmatch(r"[A-Z]{3}[/_][A-Z]{3}", symbol):
        return "forex"
    return "unknown"

def _normalize_symbol_for_provider(provider: str, raw_symbol: str) -> str:
    """
    Convert user-provided symbol variations into the exact format expected by the provider.
    - finnhub: EURUSD
    - twelvedata: EUR/USD, XAU/USD
    - oanda: EUR_USD, XAU_USD, US30, NAS100, SPX500, GER30
    """
    provider = (provider or "").lower()
    symbol = raw_symbol.upper().replace(" ", "")

    # Normalize forex forms into components
    base_quote = None
    m = re.fullmatch(r"([A-Z]{3})[/_]?([A-Z]{3})", symbol)
    if m:
        base_quote = (m.group(1), m.group(2))

    if provider == "finnhub":
        # Finnhub expects noslash format (EURUSD)
        if base_quote:
            return f"{base_quote[0]}{base_quote[1]}"
        return symbol

    if provider == "twelvedata":
        # Twelve Data expects slash for forex and XAU/USD for gold
        if base_quote:
            return f"{base_quote[0]}/{base_quote[1]}"
        if symbol in {"XAUUSD", "XAU_USD"}:
            return "XAU/USD"
        # Map common CFD index aliases to Twelve Data index tickers
        index_map = {
            "US30": "DJI",     # Dow Jones Industrial Average
            "NAS100": "NDX",   # NASDAQ-100
            "SPX500": "SPX",   # S&P 500 Index
            "GER30": "DAX",    # DAX (Germany)
        }
        return index_map.get(symbol, symbol)

    if provider == "oanda":
        # OANDA expects underscore for forex and gold
        if base_quote:
            return f"{base_quote[0]}_{base_quote[1]}"
        # Keep CFD index symbols as-is
        return symbol

    # Default: return as-is
    return symbol

def _normalize_interval_for_provider(provider: str, interval: str) -> str:
    """
    Map common interval aliases to provider-specific ones.
    """
    provider = (provider or "").lower()
    interval = (interval or "").strip()

    if provider == "finnhub":
        # Use minutes for intraday, "D" for daily
        mapping = {"1h": "60", "60": "60", "1": "1", "5m": "5", "15m": "15", "30m": "30", "1d": "D", "D": "D"}
        return mapping.get(interval, interval)
    if provider == "twelvedata":
        mapping = {"60": "1h", "1h": "1h", "1": "1min", "5": "5min", "15": "15min", "30": "30min", "1d": "1day", "D": "1day"}
        return mapping.get(interval, interval)
    if provider == "oanda":
        mapping = {"1h": "H1", "60": "H1", "H1": "H1", "M1": "M1", "M5": "M5", "M15": "M15", "M30": "M30", "D": "D", "1d": "D"}
        return mapping.get(interval, interval)
    return interval

def _normalize_request(provider: str, symbol: str, interval: str):
    """
    Normalize provider, symbol, and interval. Auto-route indices to OANDA.
    Returns (provider, symbol, interval, note)
    """
    note = None
    instrument_type = _detect_instrument_type(symbol)
    lower_provider = (provider or "").lower()

    # Auto-route indices to OANDA only if provider is neither OANDA nor TWELVEDATA
    if instrument_type == "index" and lower_provider not in {"oanda", "twelvedata"}:
        note = f"Auto-switched provider to OANDA for index symbol '{symbol}'."
        lower_provider = "oanda"

    # Normalize symbol for the chosen provider
    normalized_symbol = _normalize_symbol_for_provider(lower_provider, symbol)
    normalized_interval = _normalize_interval_for_provider(lower_provider, interval)

    # Additional: for Twelve Data, ensure gold has slash (handled above) and indices mapped

    return lower_provider, normalized_symbol, normalized_interval, note

def fetch_finnhub_forex(symbol="EURUSD", interval="1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch forex data from Finnhub API
    
    Args:
        symbol (str): Forex symbol (e.g., 'EURUSD')
        interval (str): Time interval ('1' for 1 minute, '60' for 1 hour, 'D' for daily)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Get Finnhub API key (use user's key if no environment variable)
        api_key = os.getenv('FINNHUB_API_KEY', 'd2afda1r01qoad6pkllgd2afda1r01qoad6pklm0')
        
        if not api_key:
            print("Warning: FINNHUB_API_KEY not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        # Initialize Finnhub client
        finnhub_client = finnhub.Client(api_key=api_key)
        
        # Convert dates to timestamps
        start_timestamp = int(datetime.strptime(start_str, "%Y-%m-%d").timestamp())
        end_timestamp = int(datetime.strptime(end_str, "%Y-%m-%d").timestamp())
        
        print(f"Attempting to fetch {symbol} data from Finnhub...")
        
        # Try to fetch forex data
        try:
            data = finnhub_client.forex_candles(symbol, interval, start_timestamp, end_timestamp)
            
            if data['s'] == 'ok' and len(data['t']) > 0:
                # Process the data
                df = pd.DataFrame({
                    'datetime': pd.to_datetime(data['t'], unit='s'),
                    'open': data['o'],
                    'high': data['h'],
                    'low': data['l'],
                    'close': data['c'],
                    'volume': data['v'] if 'v' in data else [1000000] * len(data['t'])
                })
                
                df = df.set_index('datetime').sort_index()
                df['symbol'] = symbol
                
                print(f"✅ Successfully fetched {len(df)} candles for {symbol} from Finnhub")
                print(f"   Date range: {df.index[0]} to {df.index[-1]}")
                
                return df
            else:
                print(f"❌ No data returned from Finnhub for {symbol}")
                print(f"   Response: {data}")
                return generate_sample_data(symbol, days=30)
                
        except Exception as forex_error:
            print(f"❌ Forex data access error: {forex_error}")
            print("   This usually means forex data is not available in the free tier.")
            print("   Trying alternative data sources...")
            
            # Try to get stock data as a test (to verify API key works)
            try:
                # Test with a stock symbol to verify API key works
                test_data = finnhub_client.quote('AAPL')
                if test_data:
                    print("✅ API key is valid, but forex data requires premium subscription.")
                    print("   Using sample data for forex trading...")
                else:
                    print("❌ API key may be invalid or expired.")
            except Exception as test_error:
                print(f"❌ API key test failed: {test_error}")
            
            return generate_sample_data(symbol, days=30)
            
    except Exception as e:
        print(f"❌ Error fetching data from Finnhub: {e}")
        print("   Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def _twelvedata_symbol_search(query_symbol: str):
    """Search Twelve Data for the best matching symbol and exchange."""
    try:
        api_key = os.getenv('TWELVEDATA_API_KEY', '85d5c52f7c4d49aa83373de0a83a8f5e')
        url = "https://api.twelvedata.com/symbol_search"
        params = {"symbol": query_symbol, "apikey": api_key}
        resp = requests.get(url, params=params)
        data = resp.json()
        if isinstance(data, dict) and 'data' in data and isinstance(data['data'], list) and data['data']:
            # Prefer indices for index-like queries
            for item in data['data']:
                if item.get('instrument_type', '').lower() in {"index", "indices"}:
                    return {"symbol": item.get('symbol'), "exchange": item.get('exchange')}
            # Fallback: first result
            item = data['data'][0]
            return {"symbol": item.get('symbol'), "exchange": item.get('exchange')}
    except Exception:
        pass
    return None

def _twelvedata_try_time_series(symbol: str, interval: str, start_str: str, end_str: str, api_key: str):
    """Try Twelve Data time_series for a single symbol, resolving exchange via symbol_search when possible."""
    resolved = _twelvedata_symbol_search(symbol)
    url = "https://api.twelvedata.com/time_series"
    params = {
        "symbol": (resolved['symbol'] if resolved and resolved.get('symbol') else symbol),
        "interval": interval,
        "start_date": start_str,
        "end_date": end_str,
        "apikey": api_key,
        "format": "JSON",
        "outputsize": "5000",
        "timezone": "UTC"
    }
    if resolved and resolved.get('exchange'):
        params["exchange"] = resolved['exchange']
    response = requests.get(url, params=params)
    data = response.json()
    if isinstance(data, dict) and 'values' in data and data['values']:
        return data, params
    return None, params if isinstance(params, dict) else None

def fetch_twelvedata_forex(symbol="EUR/USD", interval="1h", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch forex data from Twelve Data API
    
    Args:
        symbol (str): Forex symbol (e.g., 'EUR/USD')
        interval (str): Time interval ('1h' for 1 hour, '1d' for daily)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Get Twelve Data API key (use user's key if no environment variable)
        api_key = os.getenv('TWELVEDATA_API_KEY', '85d5c52f7c4d49aa83373de0a83a8f5e')
        
        if not api_key:
            print("Warning: TWELVEDATA_API_KEY not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        # Attempt fetch with smart resolution and fallbacks for indices
        print(f"Fetching {symbol} data from Twelve Data...")
        instrument_type = _detect_instrument_type(symbol)
        data = None
        final_params = None
        
        # Candidates for indices mapping if initial attempt fails
        index_fallbacks = {
            "US30": ["DJI", "^DJI"],
            "NAS100": ["NDX", "^NDX", "QQQ"],          # ETF proxy
            "SPX500": ["SPX", "^GSPC", "SPY"],         # ETF proxy
            "GER30": ["DAX", "^GDAXI", "EWG", "DAX"], # ETF proxies (iShares Germany, Global X DAX)
        }
        
        # Build attempt list
        attempt_symbols = [symbol]
        if instrument_type == "index":
            # Primary fallbacks by canonical request key
            attempt_symbols.extend(index_fallbacks.get(symbol.upper(), []))
            # Also support alias-based fallbacks when input is already an alias like NDX/DAX/SPX
            alias_fallbacks = {
                "NDX": ["^NDX", "QQQ"],
                "^NDX": ["NDX", "QQQ"],
                "SPX": ["^GSPC", "SPY"],
                "^GSPC": ["SPX", "SPY"],
                "DAX": ["^GDAXI", "EWG"],
                "^GDAXI": ["DAX", "EWG"],
                "DJI": ["^DJI"],
                "^DJI": ["DJI"],
            }
            attempt_symbols.extend(alias_fallbacks.get(symbol.upper(), []))
        
        # Intervals to try (fallback to daily for plans that don't allow intraday indices/ETFs)
        intervals_to_try = [interval]
        if interval.lower() != "1day":
            intervals_to_try.append("1day")

        # Try each candidate with exchange resolution and interval fallbacks
        for candidate in attempt_symbols:
            for itv in intervals_to_try:
                result, attempted_params = _twelvedata_try_time_series(candidate, itv, start_str, end_str, api_key)
                if result is not None:
                    data = result
                    final_params = attempted_params
                    break
            if data is not None:
                break
        
        # If still nothing and it's gold without slash, retry as XAU/USD
        if data is None and symbol.upper() in {"XAUUSD", "XAU_USD"}:
            result, attempted_params = _twelvedata_try_time_series("XAU/USD", interval, start_str, end_str, api_key)
            if result is not None:
                data = result
                final_params = attempted_params
        
        if isinstance(data, dict) and 'values' in data and data['values']:
            # Process the data
            df_data = []
            for candle in data['values']:
                df_data.append({
                    'datetime': pd.to_datetime(candle['datetime']),
                    'open': float(candle['open']),
                    'high': float(candle['high']),
                    'low': float(candle['low']),
                    'close': float(candle['close']),
                    'volume': float(candle['volume']) if 'volume' in candle else 1000000
                })
            
            df = pd.DataFrame(df_data)
            df = df.set_index('datetime').sort_index()
            df['symbol'] = symbol
            
            print(f"✅ Successfully fetched {len(df)} candles for {symbol} from Twelve Data")
            print(f"   Date range: {df.index[0]} to {df.index[-1]}")
            print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
            
            return df
        else:
            # data may be None if all attempts failed; attempted_params holds last try
            failing_symbol = (final_params or {}).get('symbol', symbol)
            print(f"❌ No data returned from Twelve Data for {failing_symbol}")
            if data is not None:
                print(f"   Response: {data}")
            return generate_sample_data(symbol, days=30)
            
    except Exception as e:
        print(f"❌ Error fetching data from Twelve Data: {e}")
        print("   Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def fetch_oanda_ohlcv(symbol="EUR_USD", interval="H1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch OHLCV data from OANDA API
    
    Args:
        symbol (str): OANDA instrument symbol (e.g., 'EUR_USD')
        interval (str): Time interval ('H1' for 1 hour)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Initialize OANDA API (you'll need to set your access token)
        # For demo purposes, we'll use sample data if no token is available
        access_token = os.getenv('OANDA_ACCESS_TOKEN')
        
        if not access_token:
            print("Warning: OANDA_ACCESS_TOKEN not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        api = API(access_token=access_token)
        
        # Set up parameters for the API request
        params = {
            "count": 5000,
            "granularity": interval,
            "from": start_str,
            "to": end_str
        }
        
        # Make the API request
        r = InstrumentsCandles(instrument=symbol, params=params)
        api.request(r)
        
        # Process the response
        data = []
        for candle in r.response['candles']:
            data.append({
                'datetime': pd.to_datetime(candle['time']),
                'open': float(candle['mid']['o']),
                'high': float(candle['mid']['h']),
                'low': float(candle['mid']['l']),
                'close': float(candle['mid']['c']),
                'volume': float(candle['volume']) if 'volume' in candle else 1000000
            })
        
        df = pd.DataFrame(data)
        df = df.set_index('datetime').sort_index()
        df['symbol'] = symbol
        
        print(f"Fetched {len(df)} candles for {symbol} from OANDA")
        print(f"Date range: {df.index[0]} to {df.index[-1]}")
        
        return df
        
    except Exception as e:
        print(f"Error fetching data from OANDA: {e}")
        print("Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def fetch_data(provider="finnhub", symbol="EURUSD", interval="1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch data from the specified provider
    
    Args:
        provider (str): Data provider ('finnhub', 'twelvedata', 'oanda', 'sample')
        symbol (str): Trading symbol
        interval (str): Time interval
        start_str (str): Start date
        end_str (str): End date
        
    Returns:
        pd.DataFrame: OHLCV data
    """
    normalized_provider, normalized_symbol, normalized_interval, note = _normalize_request(provider, symbol, interval)
    if note:
        print(note)
    print(f"Fetching data from {normalized_provider.upper()} for {normalized_symbol} (interval {normalized_interval})...")

    if normalized_provider == "finnhub":
        return fetch_finnhub_forex(normalized_symbol, normalized_interval, start_str, end_str)
    elif normalized_provider == "twelvedata":
        return fetch_twelvedata_forex(normalized_symbol, normalized_interval, start_str, end_str)
    elif normalized_provider == "oanda":
        return fetch_oanda_ohlcv(normalized_symbol, normalized_interval, start_str, end_str)
    elif provider.lower() == "sample":
        return generate_sample_data(normalized_symbol, days=30)
    else:
        print(f"Unknown provider: {provider}. Using sample data instead.")
        return generate_sample_data(normalized_symbol, days=30)

def main():
    """
    Main execution function
    """
    print("SOLOTREND X - Milestone 1")
    print("="*50)
    
    # Step 1: Load or generate data
    print("\nStep 1: Loading Data")
    print("-" * 30)

    # Choose your data provider (twelvedata, finnhub, oanda, or sample)
    data_provider = os.getenv('DATA_PROVIDER', 'twelvedata')  # Default to Twelve Data
    
    # Get trading symbol from environment variable (set by web interface)
    trading_symbol = os.getenv('TRADING_SYMBOL', 'EUR/USD')
    
    # Fetch data from the chosen provider
    df = fetch_data(
        provider=data_provider,
        symbol=trading_symbol,
        interval="1h" if data_provider == "twelvedata" else "60",
        start_str="2025-01-01",
        end_str="2025-07-13"
    )
    
    # Ensure enough data points for indicators; otherwise, fall back to sample data
    required_points = max(getattr(cfg, 'MIN_DATA_POINTS', 100), getattr(cfg, 'LOOKBACK_PERIOD', 50) * 3, 100)
    if len(df) < required_points and data_provider.lower() == 'twelvedata':
        # Attempt automatic fallback to a longer interval (daily) with extended range
        print(f"\n⚠️ Insufficient data returned ({len(df)} candles). Need at least {required_points} for feature engineering.")
        print("   Retrying with a longer interval (1day) and extended date range...")
        try:
            df_retry = fetch_data(
                provider=data_provider,
                symbol=trading_symbol,
                interval='1d',
                start_str='2024-01-01',
                end_str='2025-07-13'
            )
            if len(df_retry) >= required_points:
                print(f"✅ Fallback succeeded with {len(df_retry)} daily candles.")
                df = df_retry
            else:
                print(f"⚠️ Still insufficient after daily fallback ({len(df_retry)} candles). Using sample data.")
                df = generate_sample_data(symbol=trading_symbol, days=365)
        except Exception as _:
            print("❌ Daily fallback failed. Using sample data.")
            df = generate_sample_data(symbol=trading_symbol, days=365)
    elif len(df) < required_points:
        print(f"\n⚠️ Insufficient data returned ({len(df)} candles). Need at least {required_points} for feature engineering.")
        print("   Falling back to sample data to continue the pipeline.")
        df = generate_sample_data(symbol=trading_symbol, days=180)
    
    # Step 2: Feature Engineering
    print("\nStep 2: Feature Engineering")
    print("-" * 30)
    
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    # Optional session/volume filtering via environment variables
    session_filter = os.getenv('SESSION_FILTER', '').strip().lower()
    min_vol_ratio_env = os.getenv('MIN_VOLUME_RATIO_FILTER') or os.getenv('VOLUME_MIN_RATIO')
    
    if session_filter in {'ny', 'london', 'overlap', 'any', 'active'}:
        before = len(df_features)
        if session_filter == 'ny':
            df_features = df_features[df_features['ny_session'] == 1]
        elif session_filter == 'london':
            df_features = df_features[df_features['london_session'] == 1]
        elif session_filter in {'overlap'}:
            df_features = df_features[(df_features['ny_session'] == 1) & (df_features['london_session'] == 1)]
        else:  # any/active
            df_features = df_features[df_features['active_session'] == 1]
        print(f"Applied session filter '{session_filter}': {before} -> {len(df_features)} rows")
    
    if min_vol_ratio_env:
        try:
            min_vol_ratio = float(min_vol_ratio_env)
            before = len(df_features)
            df_features = df_features[df_features['volume_ratio'] >= min_vol_ratio]
            print(f"Applied volume filter (volume_ratio >= {min_vol_ratio}): {before} -> {len(df_features)} rows")
        except ValueError:
            print(f"Warning: Invalid MIN_VOLUME_RATIO_FILTER='{min_vol_ratio_env}', skipping volume filter")
    
    # Step 3: Signal Generation
    print("\nStep 3: Signal Generation")
    print("-" * 30)
    
    sg = SignalGenerator(risk_reward_ratios=[0.7, 0.9, 1.1])
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        # Filter signals by minimum strength
        strong_signals = sg.filter_signals(signals_df, min_strength='Super')
        
        print(f"\nSignal Summary:")
        print(f"Total signals: {len(signals_df)}")
        print(f"Strong+ signals: {len(strong_signals)}")
        
        # Display sample signals
        print(f"\nSample signals:")
        print(signals_df[['signal_type', 'entry_price', 'stop_loss', 'tp1', 'strength_score']].head())
        
        # Step 4: Backtesting
        print("\nStep 4: Backtesting")
        print("-" * 30)
        
        bt = Backtester(initial_capital=10000)
        results = bt.run_backtest(df_features, signals_df, position_size=0.02)
        
        if results:
            # Print results
            bt.print_results(results)
            
            # Step 5: Save Results
            print("\nStep 5: Saving Results")
            print("-" * 30)
            
            # Save signals to CSV
            save_signals(signals_df, 'outputs/signals_log.csv')
            
            # Save strong signals separately
            if len(strong_signals) > 0:
                save_signals(strong_signals, 'outputs/super_signals.csv')
            
            # Save backtest results
            if 'trades_df' in results:
                results['trades_df'].to_csv('outputs/backtest_trades.csv')
            
            # Step 6: Visualization
            print("\nStep 6: Visualization")
            print("-" * 30)
            
            # Plot price action with signals
            plot_signals(df_features, signals_df, 'outputs/price_signals.png')
            
            # Plot backtest results
            bt.plot_results(results, 'outputs/backtest_results.png')
            
            print("\nSOLOTREND X Milestone 1 completed successfully!")
            print("\nOutput files saved in 'outputs/' directory:")
            print("  - signals_log.csv: All generated signals")
            print("  - super_signals.csv: Strong and Super signals only")
            print("  - backtest_trades.csv: Detailed trade log")
            print("  - price_signals.png: Price chart with signals")
            print("  - backtest_results.png: Backtest performance charts")
            
    else:
        print("No signals generated. Check your data and parameters.")

def run_with_custom_data(file_path, symbol='BTCUSD'):
    """
    Run SOLOTREND X with custom data file
    
    Args:
        file_path (str): Path to CSV file
        symbol (str): Symbol name
    """
    print(f"Running SOLOTREND X with custom data: {file_path}")
    print("="*50)
    
    # Load data
    df = load_data(file_path, symbol)
    if df is None:
        print(f"Failed to load data from {file_path}")
        return
    
    # Run the complete pipeline
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    sg = SignalGenerator()
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        bt = Backtester()
        results = bt.run_backtest(df_features, signals_df)
        
        if results:
            bt.print_results(results)
            save_signals(signals_df, f'outputs/{symbol}_signals.csv')
            plot_signals(df_features, signals_df, f'outputs/{symbol}_chart.png')
            bt.plot_results(results, f'outputs/{symbol}_backtest.png')
    else:
        print("No signals generated from custom data")

if __name__ == "__main__":
    # Create outputs directory
    import os
    os.makedirs('outputs', exist_ok=True)
    
    # Run main function
    main()
    
    # Example of running with custom data (uncomment if you have data)
    # run_with_custom_data('path/to/your/data.csv', 'BTCUSD') 