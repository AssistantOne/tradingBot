"""
Debug script to analyze why no signals are being generated
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

from main import fetch_data
from solotrend_x import FeatureEngineer, SignalGenerator

def debug_signal_conditions():
    """
    Debug the signal generation conditions
    """
    print("🔍 Debugging Signal Generation Conditions")
    print("="*50)
    
    # Fetch data
    print("1. Fetching data...")
    df = fetch_data(
        provider="twelvedata",
        symbol="EUR/USD",
        interval="1h",
        start_str="2025-01-01",
        end_str="2025-01-31"  # Shorter period for debugging
    )
    
    if len(df) == 0:
        print("❌ No data fetched")
        return
    
    print(f"✅ Fetched {len(df)} data points")
    
    # Feature engineering
    print("\n2. Engineering features...")
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    print(f"✅ Engineered {len(df_features.columns)} features")
    
    # Check key features
    print("\n3. Analyzing key features...")
    
    # Check trend conditions
    hma_trend_positive = (df_features['hma_trend'] > 0).sum()
    hma_trend_negative = (df_features['hma_trend'] < 0).sum()
    print(f"   HMA Trend > 0: {hma_trend_positive} candles")
    print(f"   HMA Trend < 0: {hma_trend_negative} candles")
    
    # Check ADX conditions
    adx_strong = (df_features['adx'] > 30).sum()
    adx_weak = (df_features['adx'] <= 30).sum()
    print(f"   ADX > 30: {adx_strong} candles")
    print(f"   ADX <= 30: {adx_weak} candles")
    
    # Check session conditions
    active_sessions = df_features['active_session'].sum()
    inactive_sessions = (df_features['active_session'] == 0).sum()
    print(f"   Active sessions: {active_sessions} candles")
    print(f"   Inactive sessions: {inactive_sessions} candles")
    
    # Check volume conditions
    volume_high = (df_features['volume_ratio'] >= 1.2).sum()
    volume_low = (df_features['volume_ratio'] < 1.2).sum()
    print(f"   Volume ratio >= 1.2: {volume_high} candles")
    print(f"   Volume ratio < 1.2: {volume_low} candles")
    
    # Check pattern conditions
    bullish_engulfing = df_features['bullish_engulfing'].sum()
    bearish_engulfing = df_features['bearish_engulfing'].sum()
    hammer = df_features['hammer'].sum()
    demand_zone = df_features['demand_zone'].sum()
    supply_zone = df_features['supply_zone'].sum()
    
    print(f"   Bullish engulfing: {bullish_engulfing} candles")
    print(f"   Bearish engulfing: {bearish_engulfing} candles")
    print(f"   Hammer: {hammer} candles")
    print(f"   Demand zone: {demand_zone} candles")
    print(f"   Supply zone: {supply_zone} candles")
    
    # Check RSI conditions
    rsi_oversold = (df_features['rsi'] < 40).sum()
    rsi_overbought = (df_features['rsi'] > 60).sum()
    print(f"   RSI < 40: {rsi_oversold} candles")
    print(f"   RSI > 60: {rsi_overbought} candles")
    
    # Check order blocks
    print("\n4. Checking order blocks...")
    order_blocks = fe.find_order_blocks(df_features)
    print(f"   Support levels: {len(order_blocks['support'])}")
    print(f"   Resistance levels: {len(order_blocks['resistance'])}")
    
    if len(order_blocks['support']) > 0:
        print(f"   Support levels: {list(order_blocks['support'].keys())[:5]}")
    if len(order_blocks['resistance']) > 0:
        print(f"   Resistance levels: {list(order_blocks['resistance'].keys())[:5]}")
    
    # Test signal generation with relaxed conditions
    print("\n5. Testing signal generation with relaxed conditions...")
    
    # Create a modified signal generator with relaxed conditions
    class RelaxedSignalGenerator(SignalGenerator):
        def check_buy_conditions(self, row, order_blocks):
            """Relaxed buy conditions for debugging"""
            # Relaxed trend condition
            if row['hma_trend'] <= 0:
                return None
            
            # Relaxed ADX condition (lower threshold)
            if row['adx'] <= 15:  # Lowered from 30
                return None
            
            # Relaxed session condition (remove session requirement)
            # if not row['active_session']:
            #     return None
                
            # Relaxed volume condition
            if row['volume_ratio'] < 0.8:  # Lowered from 1.2
                return None
                
            # Check if price is near support zone (relaxed)
            current_price = row['close']
            near_support = False
            support_level = None
            
            for level, touches in order_blocks['support'].items():
                if abs(current_price - level) / level <= 0.02:  # Within 2% of support (relaxed)
                    near_support = True
                    support_level = level
                    break
            
            # If no support levels, use a simple price-based approach
            if not near_support and len(order_blocks['support']) == 0:
                # Use simple price action
                if row['rsi'] < 50 and row['close'] > row['hma_21']:
                    near_support = True
                    support_level = row['low'] * 0.995
            
            # Check for bullish patterns (relaxed)
            bullish_patterns = (
                row['bullish_engulfing'] or
                row['hammer'] or
                row['demand_zone'] or
                (row['rsi'] < 50 and row['close'] > row['hma_21'])  # Relaxed RSI condition
            )
            
            if near_support and bullish_patterns:
                # Calculate signal strength
                strength = self._calculate_signal_strength(row, 'buy')
                
                # Calculate entry, SL, and TPs
                entry_price = current_price
                stop_loss = support_level * 0.995 if support_level else entry_price * 0.995
                
                risk = entry_price - stop_loss
                tp1 = entry_price + risk * self.risk_reward_ratios[0]
                tp2 = entry_price + risk * self.risk_reward_ratios[1]
                tp3 = entry_price + risk * self.risk_reward_ratios[2]
                
                return {
                    'timestamp': row.name,
                    'signal_type': f'{strength} Buy',
                    'entry_price': entry_price,
                    'stop_loss': stop_loss,
                    'tp1': tp1,
                    'tp2': tp2,
                    'tp3': tp3,
                    'strength_score': strength,
                    'confluence_factors': self._get_confluence_factors(row, 'buy')
                }
            
            return None
    
    # Test with relaxed conditions
    relaxed_sg = RelaxedSignalGenerator()
    relaxed_signals = relaxed_sg.generate_signals(df_features, order_blocks)
    
    print(f"   Relaxed signals generated: {len(relaxed_signals)}")
    
    if len(relaxed_signals) > 0:
        print("\n   Sample relaxed signals:")
        print(relaxed_signals[['signal_type', 'entry_price', 'stop_loss', 'tp1', 'strength_score']].head())
    
    # Test with original conditions but show what's failing
    print("\n6. Testing original conditions...")
    original_sg = SignalGenerator()
    
    # Count how many candles pass each condition
    passed_trend = 0
    passed_adx = 0
    passed_session = 0
    passed_volume = 0
    passed_support = 0
    passed_patterns = 0
    
    for i in range(50, len(df_features)):
        row = df_features.iloc[i]
        
        # Check each condition
        if row['hma_trend'] > 0:
            passed_trend += 1
        
        if row['adx'] > 30:
            passed_adx += 1
        
        if row['active_session']:
            passed_session += 1
        
        if row['volume_ratio'] >= 1.2:
            passed_volume += 1
        
        # Check support proximity
        current_price = row['close']
        near_support = False
        for level in order_blocks['support'].keys():
            if abs(current_price - level) / level <= 0.01:
                near_support = True
                break
        if near_support:
            passed_support += 1
        
        # Check patterns
        bullish_patterns = (
            row['bullish_engulfing'] or
            row['hammer'] or
            row['demand_zone'] or
            (row['rsi'] < 40 and row['close'] > row['hma_21'])
        )
        if bullish_patterns:
            passed_patterns += 1
    
    print(f"   Candles passing trend condition: {passed_trend}")
    print(f"   Candles passing ADX condition: {passed_adx}")
    print(f"   Candles passing session condition: {passed_session}")
    print(f"   Candles passing volume condition: {passed_volume}")
    print(f"   Candles passing support condition: {passed_support}")
    print(f"   Candles passing pattern condition: {passed_patterns}")
    
    # Calculate combined conditions
    combined_conditions = min(passed_trend, passed_adx, passed_session, passed_volume, passed_support, passed_patterns)
    print(f"   Candles passing ALL conditions: {combined_conditions}")
    
    print("\n" + "="*50)
    print("RECOMMENDATIONS")
    print("="*50)
    
    if combined_conditions == 0:
        print("❌ No signals generated because conditions are too strict.")
        print("\n🔧 Suggested fixes:")
        print("   1. Lower ADX threshold from 30 to 15-20")
        print("   2. Lower volume ratio threshold from 1.2 to 0.8-1.0")
        print("   3. Remove or relax session requirements")
        print("   4. Increase support zone tolerance from 1% to 2%")
        print("   5. Relax RSI conditions")
        
        print("\n🎯 Quick fix - run with relaxed conditions:")
        print("   python main.py --relaxed")
    else:
        print(f"✅ {combined_conditions} signals should be generated with current conditions")

if __name__ == "__main__":
    debug_signal_conditions()
