"""
Multi-Provider Usage Examples for SOLOTREND X
Demonstrates how to use different data providers (Finnhub, Twelve Data, OANDA)
"""

import os
import sys
sys.path.append('..')

from main import fetch_data, generate_sample_data
from solotrend_x import FeatureEngineer, SignalGenerator, Backtester

def test_finnhub_provider():
    """
    Test the bot with Finnhub data provider
    """
    print("SOLOTREND X - Finnhub Data Provider Test")
    print("="*60)
    
    # Finnhub forex pairs (no slash format)
    finnhub_pairs = [
        "EURUSD",    # Euro/US Dollar
        "GBPUSD",    # British Pound/US Dollar
        "USDJPY",    # US Dollar/Japanese Yen
        "AUDUSD",    # Australian Dollar/US Dollar
        "USDCHF",    # US Dollar/Swiss Franc
        "USDCAD",    # US Dollar/Canadian Dollar
        "EURGBP",    # Euro/British Pound
        "EURJPY",    # Euro/Japanese Yen
        "GBPJPY",    # British Pound/Japanese Yen
    ]
    
    for pair in finnhub_pairs[:3]:  # Test first 3 pairs
        print(f"\nTesting {pair} with Finnhub...")
        print("-" * 40)
        
        try:
            # Fetch data from Finnhub
            df = fetch_data(
                provider="finnhub",
                symbol=pair,
                interval="60",  # 1 hour
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.5f}")
                else:
                    print("No signals generated for this pair")
            else:
                print("No data available for this pair")
                
        except Exception as e:
            print(f"Error testing {pair}: {e}")

def test_twelvedata_provider():
    """
    Test the bot with Twelve Data provider
    """
    print("\nSOLOTREND X - Twelve Data Provider Test")
    print("="*60)
    
    # Twelve Data forex pairs (with slash format)
    twelvedata_pairs = [
        "EUR/USD",    # Euro/US Dollar
        "GBP/USD",    # British Pound/US Dollar
        "USD/JPY",    # US Dollar/Japanese Yen
        "AUD/USD",    # Australian Dollar/US Dollar
        "USD/CHF",    # US Dollar/Swiss Franc
        "USD/CAD",    # US Dollar/Canadian Dollar
        "EUR/GBP",    # Euro/British Pound
        "EUR/JPY",    # Euro/Japanese Yen
        "GBP/JPY",    # British Pound/Japanese Yen
    ]
    
    for pair in twelvedata_pairs[:3]:  # Test first 3 pairs
        print(f"\nTesting {pair} with Twelve Data...")
        print("-" * 40)
        
        try:
            # Fetch data from Twelve Data
            df = fetch_data(
                provider="twelvedata",
                symbol=pair,
                interval="1h",  # 1 hour
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.5f}")
                else:
                    print("No signals generated for this pair")
            else:
                print("No data available for this pair")
                
        except Exception as e:
            print(f"Error testing {pair}: {e}")

def test_oanda_provider():
    """
    Test the bot with OANDA provider
    """
    print("\nSOLOTREND X - OANDA Provider Test")
    print("="*60)
    
    # OANDA forex pairs (with underscore format)
    oanda_pairs = [
        "EUR_USD",    # Euro/US Dollar
        "GBP_USD",    # British Pound/US Dollar
        "USD_JPY",    # US Dollar/Japanese Yen
        "AUD_USD",    # Australian Dollar/US Dollar
        "USD_CHF",    # US Dollar/Swiss Franc
        "USD_CAD",    # US Dollar/Canadian Dollar
        "EUR_GBP",    # Euro/British Pound
        "EUR_JPY",    # Euro/Japanese Yen
        "GBP_JPY",    # British Pound/Japanese Yen
    ]
    
    for pair in oanda_pairs[:3]:  # Test first 3 pairs
        print(f"\nTesting {pair} with OANDA...")
        print("-" * 40)
        
        try:
            # Fetch data from OANDA
            df = fetch_data(
                provider="oanda",
                symbol=pair,
                interval="H1",  # 1 hour
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.5f}")
                else:
                    print("No signals generated for this pair")
            else:
                print("No data available for this pair")
                
        except Exception as e:
            print(f"Error testing {pair}: {e}")

def compare_providers():
    """
    Compare different data providers with the same pair
    """
    print("\nSOLOTREND X - Provider Comparison Test")
    print("="*60)
    
    # Test EUR/USD across all providers
    test_pair = "EUR/USD"
    
    providers = [
        ("finnhub", "EURUSD", "60"),
        ("twelvedata", "EUR/USD", "1h"),
        ("oanda", "EUR_USD", "H1")
    ]
    
    results = {}
    
    for provider, symbol, interval in providers:
        print(f"\nTesting {provider.upper()} with {symbol}...")
        print("-" * 40)
        
        try:
            # Fetch data
            df = fetch_data(
                provider=provider,
                symbol=symbol,
                interval=interval,
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                results[provider] = {
                    'data_points': len(df),
                    'signals': len(signals_df),
                    'price_range': f"{df['low'].min():.5f} - {df['high'].max():.5f}",
                    'sample_signal': signals_df.iloc[0]['signal_type'] if len(signals_df) > 0 else "None"
                }
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                print(f"Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
                
                if len(signals_df) > 0:
                    print(f"Sample signal: {signals_df.iloc[0]['signal_type']}")
                else:
                    print("No signals generated")
            else:
                print("No data available")
                results[provider] = {'error': 'No data available'}
                
        except Exception as e:
            print(f"Error: {e}")
            results[provider] = {'error': str(e)}
    
    # Print comparison summary
    print("\n" + "="*60)
    print("PROVIDER COMPARISON SUMMARY")
    print("="*60)
    
    for provider, result in results.items():
        print(f"\n{provider.upper()}:")
        if 'error' in result:
            print(f"  ❌ Error: {result['error']}")
        else:
            print(f"  ✅ Data points: {result['data_points']}")
            print(f"  ✅ Signals: {result['signals']}")
            print(f"  ✅ Price range: {result['price_range']}")
            print(f"  ✅ Sample signal: {result['sample_signal']}")

def run_backtest_with_provider(provider="finnhub"):
    """
    Run a complete backtest with the specified provider
    """
    print(f"\nSOLOTREND X - Complete Backtest with {provider.upper()}")
    print("="*60)
    
    # Get symbol format for the provider
    symbol_formats = {
        "finnhub": "EURUSD",
        "twelvedata": "EUR/USD",
        "oanda": "EUR_USD"
    }
    
    interval_formats = {
        "finnhub": "60",
        "twelvedata": "1h", 
        "oanda": "H1"
    }
    
    symbol = symbol_formats.get(provider, "EURUSD")
    interval = interval_formats.get(provider, "60")
    
    try:
        # Fetch data
        df = fetch_data(
            provider=provider,
            symbol=symbol,
            interval=interval,
            start_str="2025-01-01",
            end_str="2025-02-28"
        )
        
        if len(df) > 0:
            print(f"Fetched {len(df)} data points for {symbol}")
            
            # Engineer features
            fe = FeatureEngineer()
            df_features = fe.engineer_features(df)
            
            # Generate signals
            sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
            signals_df = sg.generate_signals(df_features)
            
            print(f"Generated {len(signals_df)} signals")
            
            if len(signals_df) > 0:
                # Run backtest
                bt = Backtester(initial_capital=10000)
                results = bt.run_backtest(df_features, signals_df, position_size=0.02)
                
                if results:
                    print(f"\nBacktest Results for {provider.upper()}:")
                    print("-" * 40)
                    bt.print_results(results)
                else:
                    print("No backtest results available")
            else:
                print("No signals generated for backtesting")
        else:
            print("No data available")
            
    except Exception as e:
        print(f"Error in backtest with {provider}: {e}")

if __name__ == "__main__":
    # Check available API keys
    print("🔍 Checking available API keys...")
    print("-" * 40)
    
    api_keys = {
        "Finnhub": os.getenv('FINNHUB_API_KEY'),
        "Twelve Data": os.getenv('TWELVEDATA_API_KEY'),
        "OANDA": os.getenv('OANDA_ACCESS_TOKEN')
    }
    
    for provider, key in api_keys.items():
        if key:
            print(f"✅ {provider}: API key found")
        else:
            print(f"❌ {provider}: No API key found (will use sample data)")
    
    print("\n" + "="*60)
    print("STARTING MULTI-PROVIDER TESTS")
    print("="*60)
    
    # Run tests for each provider
    test_finnhub_provider()
    test_twelvedata_provider()
    test_oanda_provider()
    
    # Compare providers
    compare_providers()
    
    # Run backtest with default provider
    default_provider = os.getenv('DATA_PROVIDER', 'finnhub')
    run_backtest_with_provider(default_provider)
    
    print("\n" + "="*60)
    print("MULTI-PROVIDER TESTS COMPLETED")
    print("="*60)
    
    print("\n📋 Setup Instructions:")
    print("1. Get free API keys from:")
    print("   - Finnhub: https://finnhub.io/ (Free tier available)")
    print("   - Twelve Data: https://twelvedata.com/ (Free tier available)")
    print("   - OANDA: https://www.oanda.com/ (Requires verification)")
    
    print("\n2. Set environment variables:")
    print("   export FINNHUB_API_KEY='your_finnhub_key'")
    print("   export TWELVEDATA_API_KEY='your_twelvedata_key'")
    print("   export OANDA_ACCESS_TOKEN='your_oanda_token'")
    
    print("\n3. Choose your preferred provider:")
    print("   export DATA_PROVIDER='finnhub'  # or 'twelvedata' or 'oanda'")
    
    print("\n4. Run the script again to test with real data!")
