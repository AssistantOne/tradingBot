#!/usr/bin/env python3
"""
Test script to verify Unicode encoding works properly
"""

import sys
import os

# Fix Unicode encoding issues on Windows
if sys.platform.startswith('win'):
    # Set UTF-8 encoding for stdout
    sys.stdout.reconfigure(encoding='utf-8')
    # Set environment variable for matplotlib
    os.environ['PYTHONIOENCODING'] = 'utf-8'

def test_unicode():
    """Test Unicode output"""
    print("SOLOTREND X - Milestone 1")
    print("="*50)
    
    print("\nStep 1: Loading Data")
    print("-" * 30)
    print("Data loaded successfully")
    
    print("\nStep 2: Feature Engineering")
    print("-" * 30)
    print("Features engineered successfully")
    
    print("\nStep 3: Signal Generation")
    print("-" * 30)
    print("Signals generated successfully")
    
    print("\nStep 4: Backtesting")
    print("-" * 30)
    print("Backtest completed successfully")
    
    print("\nStep 5: Saving Results")
    print("-" * 30)
    print("Results saved successfully")
    
    print("\nStep 6: Visualization")
    print("-" * 30)
    print("Charts generated successfully")
    
    print("\nSOLOTREND X Milestone 1 completed successfully!")
    print("\nOutput files saved in 'outputs/' directory:")
    print("  - signals_log.csv: All generated signals")
    print("  - super_signals.csv: Strong and Super signals only")
    print("  - backtest_trades.csv: Detailed trade log")
    print("  - price_signals.png: Price chart with signals")
    print("  - backtest_results.png: Backtest performance charts")

if __name__ == "__main__":
    test_unicode() 