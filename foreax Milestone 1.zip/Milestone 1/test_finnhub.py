"""
Test script to verify Finnhub API key is working
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

from main import fetch_finnhub_forex, fetch_data

def test_finnhub_connection():
    """
    Test the Finnhub API connection with the user's key
    """
    print("🔍 Testing Finnhub API Connection")
    print("="*50)
    
    # Test with user's API key
    api_key = 'd2afda1r01qoad6pkllgd2afda1r01qoad6pklm0'
    
    print(f"Using API key: {api_key[:10]}...{api_key[-10:]}")
    print()
    
    # Test different forex pairs
    test_pairs = [
        "EURUSD",    # Euro/US Dollar
        "GBPUSD",    # British Pound/US Dollar
        "USDJPY",    # US Dollar/Japanese Yen
        "AUDUSD",    # Australian Dollar/US Dollar
        "USDCHF",    # US Dollar/Swiss Franc
    ]
    
    for pair in test_pairs:
        print(f"Testing {pair}...")
        print("-" * 30)
        
        try:
            # Fetch data for the last 7 days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)
            
            df = fetch_finnhub_forex(
                symbol=pair,
                interval="60",  # 1 hour
                start_str=start_date.strftime("%Y-%m-%d"),
                end_str=end_date.strftime("%Y-%m-%d")
            )
            
            if len(df) > 0:
                print(f"✅ Success! Fetched {len(df)} data points")
                print(f"   Date range: {df.index[0]} to {df.index[-1]}")
                print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
                print(f"   Latest close: {df['close'].iloc[-1]:.5f}")
            else:
                print(f"❌ No data returned for {pair}")
                
        except Exception as e:
            print(f"❌ Error testing {pair}: {e}")
        
        print()
    
    print("="*50)
    print("Finnhub API Test Completed!")
    print()
    print("If you see ✅ Success messages above, your API key is working correctly!")
    print("You can now run the main trading bot with real data.")

def test_main_function():
    """
    Test the main function with Finnhub data
    """
    print("\n🧪 Testing Main Function with Finnhub")
    print("="*50)
    
    try:
        # Set environment variable for testing
        os.environ['DATA_PROVIDER'] = 'finnhub'
        
        # Import and test the main function
        from main import main
        
        print("Running main function with Finnhub data...")
        print("This will test the complete pipeline with real data.")
        print()
        
        # Run the main function
        main()
        
    except Exception as e:
        print(f"❌ Error in main function: {e}")
        print("This might be expected if there are issues with the trading logic.")

if __name__ == "__main__":
    print("🚀 SOLOTREND X - Finnhub API Test")
    print("="*50)
    
    # Test the connection first
    test_finnhub_connection()
    
    # Ask user if they want to test the main function
    print("\nWould you like to test the complete trading bot with Finnhub data?")
    print("This will run the full pipeline including signal generation and backtesting.")
    
    try:
        response = input("Enter 'y' to continue or any other key to skip: ").lower().strip()
        if response == 'y':
            test_main_function()
        else:
            print("Skipping main function test.")
    except KeyboardInterrupt:
        print("\nTest interrupted by user.")
    
    print("\n✅ Finnhub API setup complete!")
    print("\nTo run the trading bot with your Finnhub data:")
    print("python main.py")
