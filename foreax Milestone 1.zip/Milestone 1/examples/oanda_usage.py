"""
OANDA Usage Examples for SOLOTREND X
Demonstrates how to use different forex pairs and instruments
"""

import os
import sys
sys.path.append('..')

from main import fetch_oanda_ohlcv, generate_sample_data
from solotrend_x import FeatureEngineer, SignalGenerator, Backtester

def test_forex_pairs():
    """
    Test the bot with different forex pairs
    """
    print("SOLOTREND X - OANDA Forex Pairs Test")
    print("="*50)
    
    # List of forex pairs to test
    forex_pairs = [
        "EUR_USD",    # Euro/US Dollar
        "GBP_USD",    # British Pound/US Dollar
        "USD_JPY",    # US Dollar/Japanese Yen
        "AUD_USD",    # Australian Dollar/US Dollar
        "USD_CHF",    # US Dollar/Swiss Franc
        "USD_CAD",    # US Dollar/Canadian Dollar
        "EUR_GBP",    # Euro/British Pound
        "EUR_JPY",    # Euro/Japanese Yen
        "GBP_JPY",    # British Pound/Japanese Yen
    ]
    
    for pair in forex_pairs:
        print(f"\nTesting {pair}...")
        print("-" * 30)
        
        try:
            # Fetch data for the pair
            df = fetch_oanda_ohlcv(
                symbol=pair,
                interval="H1",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.5f}")
                else:
                    print("No signals generated for this pair")
            else:
                print("No data available for this pair")
                
        except Exception as e:
            print(f"Error testing {pair}: {e}")

def test_indices():
    """
    Test the bot with stock indices
    """
    print("\nSOLOTREND X - OANDA Indices Test")
    print("="*50)
    
    # List of indices to test
    indices = [
        "US30",    # Dow Jones Industrial Average
        "NAS100",  # NASDAQ 100
        "SPX500",  # S&P 500
        "GER30",   # DAX
    ]
    
    for index in indices:
        print(f"\nTesting {index}...")
        print("-" * 30)
        
        try:
            # Fetch data for the index
            df = fetch_oanda_ohlcv(
                symbol=index,
                interval="H1",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.2f}")
                else:
                    print("No signals generated for this index")
            else:
                print("No data available for this index")
                
        except Exception as e:
            print(f"Error testing {index}: {e}")

def test_commodities():
    """
    Test the bot with commodities
    """
    print("\nSOLOTREND X - OANDA Commodities Test")
    print("="*50)
    
    # List of commodities to test
    commodities = [
        "XAUUSD",  # Gold
    ]
    
    for commodity in commodities:
        print(f"\nTesting {commodity}...")
        print("-" * 30)
        
        try:
            # Fetch data for the commodity
            df = fetch_oanda_ohlcv(
                symbol=commodity,
                interval="H1",
                start_str="2025-01-01",
                end_str="2025-01-31"
            )
            
            if len(df) > 0:
                # Engineer features
                fe = FeatureEngineer()
                df_features = fe.engineer_features(df)
                
                # Generate signals
                sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
                signals_df = sg.generate_signals(df_features)
                
                print(f"Data points: {len(df)}")
                print(f"Signals generated: {len(signals_df)}")
                
                if len(signals_df) > 0:
                    # Show sample signal
                    sample_signal = signals_df.iloc[0]
                    print(f"Sample signal: {sample_signal['signal_type']} at {sample_signal['entry_price']:.2f}")
                else:
                    print("No signals generated for this commodity")
            else:
                print("No data available for this commodity")
                
        except Exception as e:
            print(f"Error testing {commodity}: {e}")

def run_backtest_example():
    """
    Run a complete backtest example with EUR/USD
    """
    print("\nSOLOTREND X - Complete Backtest Example (EUR/USD)")
    print("="*60)
    
    try:
        # Fetch EUR/USD data
        df = fetch_oanda_ohlcv(
            symbol="EUR_USD",
            interval="H1",
            start_str="2025-01-01",
            end_str="2025-02-28"
        )
        
        if len(df) > 0:
            print(f"Fetched {len(df)} data points for EUR/USD")
            
            # Engineer features
            fe = FeatureEngineer()
            df_features = fe.engineer_features(df)
            
            # Generate signals
            sg = SignalGenerator(risk_reward_ratios=[1.5, 2.5, 4.0])
            signals_df = sg.generate_signals(df_features)
            
            print(f"Generated {len(signals_df)} signals")
            
            if len(signals_df) > 0:
                # Run backtest
                bt = Backtester(initial_capital=10000)
                results = bt.run_backtest(df_features, signals_df, position_size=0.02)
                
                if results:
                    print("\nBacktest Results:")
                    print("-" * 30)
                    bt.print_results(results)
                else:
                    print("No backtest results available")
            else:
                print("No signals generated for backtesting")
        else:
            print("No data available for EUR/USD")
            
    except Exception as e:
        print(f"Error in backtest example: {e}")

if __name__ == "__main__":
    # Check if OANDA token is available
    if not os.getenv('OANDA_ACCESS_TOKEN'):
        print("Warning: OANDA_ACCESS_TOKEN not found.")
        print("The examples will use sample data instead of real OANDA data.")
        print("To use real data, set your OANDA access token as an environment variable.")
        print()
    
    # Run examples
    test_forex_pairs()
    test_indices()
    test_commodities()
    run_backtest_example()
    
    print("\nOANDA Examples completed!")
    print("\nTo use real OANDA data:")
    print("1. Get your OANDA access token from your account")
    print("2. Set environment variable: export OANDA_ACCESS_TOKEN='your_token'")
    print("3. Run this script again")
