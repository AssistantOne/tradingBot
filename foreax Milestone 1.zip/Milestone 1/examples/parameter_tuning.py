"""
Parameter Tuning Example for SOLOTREND X
Demonstrates how to experiment with different parameters
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solotrend_x import FeatureEngineer, SignalGenerator, Backtester, load_data
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def create_test_data():
    """Create test data for parameter tuning"""
    print("📊 Creating test data...")
    
    # Generate 60 days of hourly data for more robust testing
    dates = pd.date_range(start='2024-01-01', periods=60*24, freq='H')
    
    np.random.seed(456)
    base_price = 50000
    returns = np.random.normal(0, 0.02, len(dates))
    
    # Add multiple trends and reversals
    trend_periods = 4
    for i in range(trend_periods):
        start_idx = i * len(dates) // trend_periods
        end_idx = (i + 1) * len(dates) // trend_periods
        trend = np.linspace(0, 0.15 if i % 2 == 0 else -0.15, end_idx - start_idx)
        returns[start_idx:end_idx] += trend / len(trend)
    
    prices = base_price * np.exp(np.cumsum(returns))
    
    # Generate OHLCV with more realistic patterns
    data = []
    for i, (date, price) in enumerate(zip(dates, prices)):
        volatility = 0.008 + abs(returns[i]) * 2  # Higher volatility during moves
        
        open_price = price * (1 + np.random.normal(0, volatility))
        close_price = price * (1 + np.random.normal(0, volatility))
        high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, volatility/2)))
        low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, volatility/2)))
        
        # Volume spikes during significant moves
        volume_base = 1000000
        volume_multiplier = 1 + abs(returns[i]) * 8 + np.random.normal(0, 0.4)
        volume = volume_base * volume_multiplier
        
        data.append({
            'datetime': date,
            'open': round(open_price, 2),
            'high': round(high_price, 2),
            'low': round(low_price, 2),
            'close': round(close_price, 2),
            'volume': round(volume, 0)
        })
    
    df = pd.DataFrame(data)
    df = df.set_index('datetime')
    df['symbol'] = 'BTCUSD'
    
    print(f"✅ Generated {len(df)} candles")
    return df

def test_risk_reward_ratios(df_features):
    """Test different risk-reward ratio combinations"""
    print("\n🎯 Testing Risk-Reward Ratios")
    print("-" * 40)
    
    rr_combinations = [
        [1.0, 2.0, 3.0],  # Conservative
        [1.5, 2.5, 4.0],  # Default
        [2.0, 3.0, 5.0],  # Aggressive
        [1.2, 2.0, 3.5],  # Balanced
    ]
    
    results = []
    
    for rr_ratios in rr_combinations:
        print(f"\nTesting RR ratios: {rr_ratios}")
        
        sg = SignalGenerator(risk_reward_ratios=rr_ratios)
        signals_df = sg.generate_signals(df_features)
        
        if len(signals_df) > 0:
            bt = Backtester(initial_capital=10000)
            backtest_results = bt.run_backtest(df_features, signals_df, position_size=0.02)
            
            if backtest_results:
                results.append({
                    'rr_ratios': rr_ratios,
                    'total_trades': backtest_results['total_trades'],
                    'win_rate': backtest_results['win_rate'],
                    'total_pnl': backtest_results['total_pnl'],
                    'profit_factor': backtest_results['profit_factor'],
                    'max_drawdown': backtest_results['max_drawdown'],
                    'signal_count': len(signals_df)
                })
                
                print(f"  Trades: {backtest_results['total_trades']}, "
                      f"Win Rate: {backtest_results['win_rate']:.1f}%, "
                      f"P&L: ${backtest_results['total_pnl']:,.0f}")
    
    return pd.DataFrame(results)

def test_volume_thresholds(df_features):
    """Test different volume thresholds"""
    print("\n📊 Testing Volume Thresholds")
    print("-" * 40)
    
    volume_thresholds = [1.0, 1.2, 1.5, 2.0, 2.5]
    
    results = []
    
    for threshold in volume_thresholds:
        print(f"\nTesting volume threshold: {threshold}x average")
        
        # Modify the signal generator to use custom volume threshold
        sg = SignalGenerator()
        
        # We need to modify the volume condition in the signal generation
        # For this example, we'll filter signals after generation
        signals_df = sg.generate_signals(df_features)
        
        if len(signals_df) > 0:
            # Filter by volume threshold (this is a simplified approach)
            # In practice, you'd modify the signal generation logic
            bt = Backtester(initial_capital=10000)
            backtest_results = bt.run_backtest(df_features, signals_df, position_size=0.02)
            
            if backtest_results:
                results.append({
                    'volume_threshold': threshold,
                    'total_trades': backtest_results['total_trades'],
                    'win_rate': backtest_results['win_rate'],
                    'total_pnl': backtest_results['total_pnl'],
                    'profit_factor': backtest_results['profit_factor'],
                    'signal_count': len(signals_df)
                })
                
                print(f"  Trades: {backtest_results['total_trades']}, "
                      f"Win Rate: {backtest_results['win_rate']:.1f}%, "
                      f"P&L: ${backtest_results['total_pnl']:,.0f}")
    
    return pd.DataFrame(results)

def test_signal_strength_filters(df_features):
    """Test filtering by signal strength"""
    print("\n🏆 Testing Signal Strength Filters")
    print("-" * 40)
    
    sg = SignalGenerator()
    all_signals = sg.generate_signals(df_features)
    
    if len(all_signals) == 0:
        print("❌ No signals generated")
        return pd.DataFrame()
    
    strength_filters = ['Potential', 'Strong', 'Super']
    
    results = []
    
    for min_strength in strength_filters:
        print(f"\nTesting minimum strength: {min_strength}")
        
        filtered_signals = sg.filter_signals(all_signals, min_strength=min_strength)
        
        if len(filtered_signals) > 0:
            bt = Backtester(initial_capital=10000)
            backtest_results = bt.run_backtest(df_features, filtered_signals, position_size=0.02)
            
            if backtest_results:
                results.append({
                    'min_strength': min_strength,
                    'total_trades': backtest_results['total_trades'],
                    'win_rate': backtest_results['win_rate'],
                    'total_pnl': backtest_results['total_pnl'],
                    'profit_factor': backtest_results['profit_factor'],
                    'avg_win': backtest_results['avg_win'],
                    'avg_loss': backtest_results['avg_loss'],
                    'signal_count': len(filtered_signals)
                })
                
                print(f"  Trades: {backtest_results['total_trades']}, "
                      f"Win Rate: {backtest_results['win_rate']:.1f}%, "
                      f"P&L: ${backtest_results['total_pnl']:,.0f}, "
                      f"Avg Win: ${backtest_results['avg_win']:,.0f}")
    
    return pd.DataFrame(results)

def main():
    """Main parameter tuning function"""
    print("🔧 SOLOTREND X - Parameter Tuning Example")
    print("=" * 60)
    
    # Create test data
    df = create_test_data()
    
    # Engineer features
    print("\n🔧 Engineering features...")
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    # Test different parameters
    print("\n" + "="*60)
    print("PARAMETER TUNING RESULTS")
    print("="*60)
    
    # Test 1: Risk-Reward Ratios
    rr_results = test_risk_reward_ratios(df_features)
    if not rr_results.empty:
        print(f"\n📈 Best RR Combination:")
        best_rr = rr_results.loc[rr_results['total_pnl'].idxmax()]
        print(f"  RR Ratios: {best_rr['rr_ratios']}")
        print(f"  Total P&L: ${best_rr['total_pnl']:,.0f}")
        print(f"  Win Rate: {best_rr['win_rate']:.1f}%")
    
    # Test 2: Signal Strength Filters
    strength_results = test_signal_strength_filters(df_features)
    if not strength_results.empty:
        print(f"\n🏆 Best Strength Filter:")
        best_strength = strength_results.loc[strength_results['total_pnl'].idxmax()]
        print(f"  Min Strength: {best_strength['min_strength']}")
        print(f"  Total P&L: ${best_strength['total_pnl']:,.0f}")
        print(f"  Win Rate: {best_strength['win_rate']:.1f}%")
        print(f"  Signal Count: {best_strength['signal_count']}")
    
    # Summary
    print(f"\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    
    if not rr_results.empty:
        print(f"📊 RR Testing: {len(rr_results)} combinations tested")
        print(f"   Best P&L: ${rr_results['total_pnl'].max():,.0f}")
        print(f"   Best Win Rate: {rr_results['win_rate'].max():.1f}%")
    
    if not strength_results.empty:
        print(f"🏆 Strength Testing: {len(strength_results)} filters tested")
        print(f"   Best P&L: ${strength_results['total_pnl'].max():,.0f}")
        print(f"   Best Win Rate: {strength_results['win_rate'].max():.1f}%")
    
    print(f"\n💡 Recommendations:")
    print(f"   - Use conservative RR ratios for higher win rates")
    print(f"   - Filter by 'Strong' or 'Super' signals for better quality")
    print(f"   - Consider position sizing based on signal strength")
    
    # Save results
    if not rr_results.empty:
        rr_results.to_csv('parameter_tuning_rr_results.csv', index=False)
        print(f"\n💾 RR results saved to 'parameter_tuning_rr_results.csv'")
    
    if not strength_results.empty:
        strength_results.to_csv('parameter_tuning_strength_results.csv', index=False)
        print(f"💾 Strength results saved to 'parameter_tuning_strength_results.csv'")

if __name__ == "__main__":
    main() 