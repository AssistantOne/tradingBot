"""
Test different trading pairs with SOLOTREND X
"""

import os
import sys
from datetime import datetime, timedelta

# Add the current directory to the path
sys.path.append('.')

from main import fetch_data
from solotrend_x import FeatureEngineer, SignalGenerator, Backtester

def test_single_pair(symbol, days=30):
    """
    Test a single trading pair
    """
    print(f"\n🔍 Testing {symbol}")
    print("-" * 40)
    
    try:
        # Fetch data
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        df = fetch_data(
            provider="twelvedata",
            symbol=symbol,
            interval="1h",
            start_str=start_date.strftime("%Y-%m-%d"),
            end_str=end_date.strftime("%Y-%m-%d")
        )
        
        if len(df) == 0:
            print(f"❌ No data available for {symbol}")
            return None
        
        print(f"✅ Fetched {len(df)} data points")
        print(f"   Date range: {df.index[0]} to {df.index[-1]}")
        print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
        print(f"   Latest close: {df['close'].iloc[-1]:.5f}")
        
        # Feature engineering
        fe = FeatureEngineer()
        df_features = fe.engineer_features(df)
        
        # Signal generation
        sg = SignalGenerator()
        signals_df = sg.generate_signals(df_features)
        
        if len(signals_df) == 0:
            print(f"⚠️ No signals generated for {symbol}")
            return None
        
        print(f"🎯 Generated {len(signals_df)} signals")
        
        # Show signal breakdown
        signal_counts = signals_df['signal_type'].value_counts()
        print("   Signal breakdown:")
        for signal_type, count in signal_counts.items():
            print(f"     {signal_type}: {count}")
        
        # Backtesting
        bt = Backtester(initial_capital=10000)
        results = bt.run_backtest(df_features, signals_df, position_size=0.02)
        
        if results:
            print(f"📈 Backtest Results:")
            print(f"   Trades: {results['total_trades']}")
            print(f"   Win Rate: {results['win_rate']:.1f}%")
            print(f"   Total P&L: ${results['total_pnl']:,.0f}")
            print(f"   Profit Factor: {results['profit_factor']:.2f}")
            
            return {
                'symbol': symbol,
                'data_points': len(df),
                'signals': len(signals_df),
                'trades': results['total_trades'],
                'win_rate': results['win_rate'],
                'total_pnl': results['total_pnl'],
                'profit_factor': results['profit_factor']
            }
        else:
            print(f"⚠️ No backtest results for {symbol}")
            return None
            
    except Exception as e:
        print(f"❌ Error testing {symbol}: {e}")
        return None

def main():
    """
    Main function to test multiple pairs
    """
    print("🚀 SOLOTREND X - Trading Pairs Test")
    print("="*50)
    
    # Test pairs by category
    test_pairs = {
        'Major Forex': ['EUR/USD', 'GBP/USD', 'USD/JPY'],
        'Minor Forex': ['EUR/GBP', 'GBP/JPY', 'AUD/JPY'],
        'Indices': ['US30', 'NAS100'],
        'Commodities': ['XAUUSD']
    }
    
    results = []
    
    for category, pairs in test_pairs.items():
        print(f"\n📊 {category}")
        print("=" * 30)
        
        for pair in pairs:
            result = test_single_pair(pair, days=30)
            if result:
                results.append(result)
    
    # Print summary
    if results:
        print("\n" + "="*60)
        print("📊 SUMMARY RESULTS")
        print("="*60)
        
        print(f"{'Symbol':<12} {'Data':<6} {'Signals':<8} {'Trades':<8} {'Win Rate':<10} {'P&L':<12} {'Profit Factor':<12}")
        print("-" * 80)
        
        for result in results:
            print(f"{result['symbol']:<12} {result['data_points']:<6} {result['signals']:<8} {result['trades']:<8} {result['win_rate']:<10.1f}% ${result['total_pnl']:<11,.0f} {result['profit_factor']:<12.2f}")
        
        # Find best performers
        print("\n🏆 TOP PERFORMERS")
        print("-" * 30)
        
        # Best by P&L
        best_pnl = max(results, key=lambda x: x['total_pnl'])
        print(f"💰 Best P&L: {best_pnl['symbol']} (${best_pnl['total_pnl']:,.0f})")
        
        # Best by win rate
        best_winrate = max(results, key=lambda x: x['win_rate'])
        print(f"🎯 Best Win Rate: {best_winrate['symbol']} ({best_winrate['win_rate']:.1f}%)")
        
        # Best by profit factor
        best_pf = max(results, key=lambda x: x['profit_factor'])
        print(f"📈 Best Profit Factor: {best_pf['symbol']} ({best_pf['profit_factor']:.2f})")
        
        # Most signals
        most_signals = max(results, key=lambda x: x['signals'])
        print(f"📊 Most Signals: {most_signals['symbol']} ({most_signals['signals']} signals)")
    
    print("\n" + "="*60)
    print("🎯 RECOMMENDATIONS")
    print("="*60)
    print("1. Choose pairs with high win rates and profit factors")
    print("2. Consider trading multiple pairs for diversification")
    print("3. Focus on pairs that generate consistent signals")
    print("4. Monitor performance regularly and adjust strategies")
    print("\n🚀 Your trading bot is ready for multi-pair trading!")

if __name__ == "__main__":
    main()
