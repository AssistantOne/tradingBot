#!/usr/bin/env python3
"""
SOLOTREND X - Web Interface Startup Script

This script starts the web dashboard for the SOLOTREND X trading bot.
"""

import os
import sys
import subprocess

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import flask
        print("✅ Flask is installed")
    except ImportError:
        print("❌ Flask is not installed. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "flask"])
        print("✅ Flask installed successfully")

def create_directories():
    """Create necessary directories"""
    directories = ['outputs', 'templates']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"✅ Created {directory} directory")

def main():
    """Main function"""
    print("🚀 SOLOTREND X - Web Dashboard")
    print("=" * 40)
    
    # Check dependencies
    check_dependencies()
    
    # Create directories
    create_directories()
    
    print("\n🌐 Starting web server...")
    print("📊 Dashboard will be available at: http://localhost:5000")
    print("🛑 Press Ctrl+C to stop the server")
    print("=" * 40)
    
    # Start the Flask app
    try:
        from app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")

if __name__ == "__main__":
    main() 