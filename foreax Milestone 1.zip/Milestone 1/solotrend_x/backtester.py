"""
SOLOTREND X - Backtester Module
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to prevent popup windows
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class Backtester:
    """
    Backtesting class for SOLOTREND X trading bot
    """
    
    def __init__(self, initial_capital=10000):
        """
        Initialize backtester
        
        Args:
            initial_capital (float): Initial capital for backtesting
        """
        self.initial_capital = initial_capital
        self.trades = []
        self.equity_curve = []
        
    def run_backtest(self, df, signals_df, position_size=0.02):
        """
        Run backtest on signals
        
        Args:
            df (pd.DataFrame): OHLCV data
            signals_df (pd.DataFrame): Signals dataframe
            position_size (float): Position size as fraction of capital
            
        Returns:
            dict: Backtest results
        """
        print("Running backtest...")
        
        if len(signals_df) == 0:
            print("No signals to backtest")
            return {}
        
        # Initialize tracking variables
        capital = self.initial_capital
        open_trades = []
        closed_trades = []
        equity_curve = []
        
        # Loop through each candle
        for i in range(len(df)):
            current_time = df.index[i]
            current_candle = df.iloc[i]
            
            # Check for new signals
            new_signals = signals_df[signals_df.index == current_time]
            
            for _, signal in new_signals.iterrows():
                # Calculate position size
                risk_amount = capital * position_size
                risk_per_share = abs(signal['entry_price'] - signal['stop_loss'])
                shares = risk_amount / risk_per_share if risk_per_share > 0 else 0
                
                # Open new trade
                trade = {
                    'entry_time': current_time,
                    'entry_price': signal['entry_price'],
                    'stop_loss': signal['stop_loss'],
                    'tp1': signal['tp1'],
                    'tp2': signal['tp2'],
                    'tp3': signal['tp3'],
                    'shares': shares,
                    'signal_type': signal['signal_type'],
                    'strength_score': signal['strength_score'],
                    'confluence_factors': signal['confluence_factors'],
                    'status': 'open',
                    'exit_time': None,
                    'exit_price': None,
                    'exit_reason': None,
                    'pnl': 0,
                    'pnl_pct': 0
                }
                
                open_trades.append(trade)
            
            # Check existing trades for exits
            for trade in open_trades[:]:  # Copy list to avoid modification during iteration
                if trade['status'] == 'open':
                    exit_result = self._check_exit_conditions(trade, current_candle, current_time)
                    
                    if exit_result:
                        trade.update(exit_result)
                        trade['status'] = 'closed'
                        
                        # Calculate PnL
                        if 'Buy' in trade['signal_type']:
                            trade['pnl'] = (trade['exit_price'] - trade['entry_price']) * trade['shares']
                        else:  # Sell
                            trade['pnl'] = (trade['entry_price'] - trade['exit_price']) * trade['shares']
                        
                        trade['pnl_pct'] = (trade['pnl'] / (trade['entry_price'] * trade['shares'])) * 100
                        
                        # Update capital
                        capital += trade['pnl']
                        
                        closed_trades.append(trade)
                        open_trades.remove(trade)
            
            # Record equity
            equity_curve.append({
                'timestamp': current_time,
                'capital': capital,
                'open_trades': len(open_trades)
            })
        
        # Close any remaining open trades at last price
        for trade in open_trades:
            trade['exit_time'] = df.index[-1]
            trade['exit_price'] = df.iloc[-1]['close']
            trade['exit_reason'] = 'End of data'
            trade['status'] = 'closed'
            
            if 'Buy' in trade['signal_type']:
                trade['pnl'] = (trade['exit_price'] - trade['entry_price']) * trade['shares']
            else:
                trade['pnl'] = (trade['entry_price'] - trade['exit_price']) * trade['shares']
            
            trade['pnl_pct'] = (trade['pnl'] / (trade['entry_price'] * trade['shares'])) * 100
            capital += trade['pnl']
            closed_trades.append(trade)
        
        # Calculate statistics
        results = self._calculate_statistics(closed_trades, equity_curve)
        
        print(f"Backtest completed: {len(closed_trades)} trades, Final capital: ${capital:.2f}")
        
        return results
    
    def _check_exit_conditions(self, trade, current_candle, current_time):
        """
        Check if trade should be exited
        
        Args:
            trade (dict): Trade information
            current_candle (pd.Series): Current candle data
            current_time (datetime): Current timestamp
            
        Returns:
            dict: Exit information if conditions met, None otherwise
        """
        high = current_candle['high']
        low = current_candle['low']
        
        # Check stop loss
        if 'Buy' in trade['signal_type']:
            if low <= trade['stop_loss']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['stop_loss'],
                    'exit_reason': 'Stop Loss'
                }
            
            # Check take profits
            if high >= trade['tp3']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp3'],
                    'exit_reason': 'TP3'
                }
            elif high >= trade['tp2']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp2'],
                    'exit_reason': 'TP2'
                }
            elif high >= trade['tp1']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp1'],
                    'exit_reason': 'TP1'
                }
        
        else:  # Sell signal
            if high >= trade['stop_loss']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['stop_loss'],
                    'exit_reason': 'Stop Loss'
                }
            
            # Check take profits
            if low <= trade['tp3']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp3'],
                    'exit_reason': 'TP3'
                }
            elif low <= trade['tp2']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp2'],
                    'exit_reason': 'TP2'
                }
            elif low <= trade['tp1']:
                return {
                    'exit_time': current_time,
                    'exit_price': trade['tp1'],
                    'exit_reason': 'TP1'
                }
        
        return None
    
    def _calculate_statistics(self, trades, equity_curve):
        """
        Calculate backtest statistics
        
        Args:
            trades (list): List of closed trades
            equity_curve (list): Equity curve data
            
        Returns:
            dict: Backtest statistics
        """
        if not trades:
            return {}
        
        # Convert to dataframe
        trades_df = pd.DataFrame(trades)
        equity_df = pd.DataFrame(equity_curve)
        
        # Basic statistics
        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['pnl'] > 0])
        losing_trades = len(trades_df[trades_df['pnl'] < 0])
        
        win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
        
        # PnL statistics
        total_pnl = trades_df['pnl'].sum()
        avg_win = trades_df[trades_df['pnl'] > 0]['pnl'].mean() if winning_trades > 0 else 0
        avg_loss = trades_df[trades_df['pnl'] < 0]['pnl'].mean() if losing_trades > 0 else 0
        
        profit_factor = abs(avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 else float('inf')
        
        # Take profit hit rates
        tp1_hits = len(trades_df[trades_df['exit_reason'] == 'TP1'])
        tp2_hits = len(trades_df[trades_df['exit_reason'] == 'TP2'])
        tp3_hits = len(trades_df[trades_df['exit_reason'] == 'TP3'])
        sl_hits = len(trades_df[trades_df['exit_reason'] == 'Stop Loss'])
        
        tp1_rate = (tp1_hits / total_trades) * 100 if total_trades > 0 else 0
        tp2_rate = (tp2_hits / total_trades) * 100 if total_trades > 0 else 0
        tp3_rate = (tp3_hits / total_trades) * 100 if total_trades > 0 else 0
        sl_rate = (sl_hits / total_trades) * 100 if total_trades > 0 else 0
        
        # Drawdown calculation
        equity_df['drawdown'] = (equity_df['capital'] - equity_df['capital'].cummax()) / equity_df['capital'].cummax() * 100
        max_drawdown = equity_df['drawdown'].min()
        
        # Signal strength analysis
        strength_stats = trades_df.groupby('strength_score').agg({
            'pnl': ['count', 'sum', 'mean'],
            'pnl_pct': 'mean'
        }).round(2)
        
        # Confluence factor analysis
        all_factors = []
        for factors in trades_df['confluence_factors']:
            if isinstance(factors, list):
                all_factors.extend(factors)
        
        factor_counts = pd.Series(all_factors).value_counts()
        
        return {
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': round(win_rate, 2),
            'total_pnl': round(total_pnl, 2),
            'avg_win': round(avg_win, 2),
            'avg_loss': round(avg_loss, 2),
            'profit_factor': round(profit_factor, 2),
            'tp1_hits': tp1_hits,
            'tp2_hits': tp2_hits,
            'tp3_hits': tp3_hits,
            'sl_hits': sl_hits,
            'tp1_rate': round(tp1_rate, 2),
            'tp2_rate': round(tp2_rate, 2),
            'tp3_rate': round(tp3_rate, 2),
            'sl_rate': round(sl_rate, 2),
            'max_drawdown': round(max_drawdown, 2),
            'final_capital': round(equity_df['capital'].iloc[-1], 2),
            'total_return': round(((equity_df['capital'].iloc[-1] - self.initial_capital) / self.initial_capital) * 100, 2),
            'strength_stats': strength_stats,
            'factor_counts': factor_counts,
            'trades_df': trades_df,
            'equity_df': equity_df
        }
    
    def print_results(self, results):
        """
        Print backtest results in a formatted way
        
        Args:
            results (dict): Backtest results
        """
        if not results:
            print("No results to display")
            return
        
        print("\n" + "="*60)
        print("SOLOTREND X - BACKTEST RESULTS")
        print("="*60)
        
        print(f"\n📊 TRADE STATISTICS:")
        print(f"Total Trades: {results['total_trades']}")
        print(f"Winning Trades: {results['winning_trades']}")
        print(f"Losing Trades: {results['losing_trades']}")
        print(f"Win Rate: {results['win_rate']}%")
        
        print(f"\n💰 P&L ANALYSIS:")
        print(f"Total P&L: ${results['total_pnl']:,.2f}")
        print(f"Average Win: ${results['avg_win']:,.2f}")
        print(f"Average Loss: ${results['avg_loss']:,.2f}")
        print(f"Profit Factor: {results['profit_factor']}")
        print(f"Total Return: {results['total_return']}%")
        print(f"Final Capital: ${results['final_capital']:,.2f}")
        
        print(f"\n🎯 TAKE PROFIT ANALYSIS:")
        print(f"TP1 Hit Rate: {results['tp1_rate']}% ({results['tp1_hits']} hits)")
        print(f"TP2 Hit Rate: {results['tp2_rate']}% ({results['tp2_hits']} hits)")
        print(f"TP3 Hit Rate: {results['tp3_rate']}% ({results['tp3_hits']} hits)")
        print(f"Stop Loss Rate: {results['sl_rate']}% ({results['sl_hits']} hits)")
        
        print(f"\n📉 RISK METRICS:")
        print(f"Maximum Drawdown: {results['max_drawdown']}%")
        
        print(f"\n🏆 SIGNAL STRENGTH ANALYSIS:")
        print(results['strength_stats'])
        
        print(f"\n🔍 TOP CONFLUENCE FACTORS:")
        top_factors = results['factor_counts'].head(5)
        for factor, count in top_factors.items():
            print(f"  {factor}: {count} occurrences")
        
        print("="*60)
    
    def plot_results(self, results, save_path=None):
        """
        Plot backtest results
        
        Args:
            results (dict): Backtest results
            save_path (str): Path to save plot
        """
        if not results:
            print("No results to plot")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Equity curve
        equity_df = results['equity_df']
        axes[0, 0].plot(equity_df['timestamp'], equity_df['capital'])
        axes[0, 0].set_title('Equity Curve')
        axes[0, 0].set_ylabel('Capital ($)')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Drawdown
        axes[0, 1].fill_between(equity_df['timestamp'], equity_df['drawdown'], 0, alpha=0.3, color='red')
        axes[0, 1].set_title('Drawdown')
        axes[0, 1].set_ylabel('Drawdown (%)')
        axes[0, 1].grid(True, alpha=0.3)
        
        # P&L distribution
        trades_df = results['trades_df']
        axes[1, 0].hist(trades_df['pnl'], bins=20, alpha=0.7, color='blue')
        axes[1, 0].set_title('P&L Distribution')
        axes[1, 0].set_xlabel('P&L ($)')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Exit reasons pie chart
        exit_reasons = trades_df['exit_reason'].value_counts()
        axes[1, 1].pie(exit_reasons.values, labels=exit_reasons.index, autopct='%1.1f%%')
        axes[1, 1].set_title('Exit Reasons')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Backtest plot saved to {save_path}")
        
        plt.close()  # Close the figure to free memory 