"""
Signal Generation Module for SOLOTREND X
Implements rule-based trading logic for Buy/Sell signals
"""

import pandas as pd
import numpy as np
from .utils import calculate_risk_reward_ratios

class SignalGenerator:
    """
    Signal generation class for SOLOTREND X trading bot
    """
    
    def __init__(self, risk_reward_ratios=[1.5, 2.5, 4.0]):
        """
        Initialize signal generator
        
        Args:
            risk_reward_ratios (list): RR ratios for TP1, TP2, TP3
        """
        self.risk_reward_ratios = risk_reward_ratios
        self.signals = []
        
    def check_buy_conditions(self, row, order_blocks):
        """
        Check buy signal conditions
        
        Args:
            row (pd.Series): Current candle data
            order_blocks (dict): Order block zones
            
        Returns:
            dict: Buy signal if conditions met, None otherwise
        """
        # Basic trend condition
        if row['hma_trend'] <= 0:
            return None
        
        # Relaxed ADX condition (lowered from 30 to 15)
        if row['adx'] <= 15:
            return None
        
        # Relaxed session condition (optional - can be commented out)
        # if not row['active_session']:
        #     return None
            
        # Relaxed volume condition (lowered from 1.2 to 0.8)
        if row['volume_ratio'] < 0.8:
            return None
            
        # Check if price is near support zone (relaxed tolerance)
        current_price = row['close']
        near_support = False
        support_level = None
        
        for level, touches in order_blocks['support'].items():
            if abs(current_price - level) / level <= 0.02:  # Within 2% of support (relaxed from 1%)
                near_support = True
                support_level = level
                break
        
        # If no support levels found, use simple price action
        if not near_support and len(order_blocks['support']) == 0:
            # Use simple price action when no support levels are available
            if row['rsi'] < 50 and row['close'] > row['hma_21']:
                near_support = True
                support_level = row['low'] * 0.995
        
        # Check for bullish patterns (relaxed RSI condition)
        bullish_patterns = (
            row['bullish_engulfing'] or
            row['hammer'] or
            row['demand_zone'] or
            (row['rsi'] < 50 and row['close'] > row['hma_21'])  # Relaxed from RSI < 40
        )
        
        if near_support and bullish_patterns:
            # Calculate signal strength
            strength = self._calculate_signal_strength(row, 'buy')
            
            # Calculate entry, SL, and TPs
            entry_price = current_price
            stop_loss = support_level * 0.995 if support_level else entry_price * 0.995
            
            risk = entry_price - stop_loss
            tp1 = entry_price + risk * self.risk_reward_ratios[0]
            tp2 = entry_price + risk * self.risk_reward_ratios[1]
            tp3 = entry_price + risk * self.risk_reward_ratios[2]
            
            return {
                'timestamp': row.name,
                'signal_type': f'{strength} Buy',
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'tp1': tp1,
                'tp2': tp2,
                'tp3': tp3,
                'strength_score': strength,
                'confluence_factors': self._get_confluence_factors(row, 'buy')
            }
        
        return None
    
    def check_sell_conditions(self, row, order_blocks):
        """
        Check sell signal conditions
        
        Args:
            row (pd.Series): Current candle data
            order_blocks (dict): Order block zones
            
        Returns:
            dict: Sell signal if conditions met, None otherwise
        """
        # Basic trend condition
        if row['hma_trend'] >= 0:
            return None
        
        # Relaxed ADX condition (lowered from 30 to 15)
        if row['adx'] <= 15:
            return None
        
        # Relaxed session condition (optional - can be commented out)
        # if not row['active_session']:
        #     return None
            
        # Relaxed volume condition (lowered from 1.2 to 0.8)
        if row['volume_ratio'] < 0.8:
            return None
            
        # Check if price is near resistance zone (relaxed tolerance)
        current_price = row['close']
        near_resistance = False
        resistance_level = None
        
        for level, touches in order_blocks['resistance'].items():
            if abs(current_price - level) / level <= 0.02:  # Within 2% of resistance (relaxed from 1%)
                near_resistance = True
                resistance_level = level
                break
        
        # If no resistance levels found, use simple price action
        if not near_resistance and len(order_blocks['resistance']) == 0:
            # Use simple price action when no resistance levels are available
            if row['rsi'] > 50 and row['close'] < row['hma_21']:
                near_resistance = True
                resistance_level = row['high'] * 1.005
        
        # Check for bearish patterns (relaxed RSI condition)
        bearish_patterns = (
            row['bearish_engulfing'] or
            row['supply_zone'] or
            (row['rsi'] > 50 and row['close'] < row['hma_21'])  # Relaxed from RSI > 60
        )
        
        if near_resistance and bearish_patterns:
            # Calculate signal strength
            strength = self._calculate_signal_strength(row, 'sell')
            
            # Calculate entry, SL, and TPs
            entry_price = current_price
            stop_loss = resistance_level * 1.005 if resistance_level else entry_price * 1.005
            
            risk = stop_loss - entry_price
            tp1 = entry_price - risk * self.risk_reward_ratios[0]
            tp2 = entry_price - risk * self.risk_reward_ratios[1]
            tp3 = entry_price - risk * self.risk_reward_ratios[2]
            
            return {
                'timestamp': row.name,
                'signal_type': f'{strength} Sell',
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'tp1': tp1,
                'tp2': tp2,
                'tp3': tp3,
                'strength_score': strength,
                'confluence_factors': self._get_confluence_factors(row, 'sell')
            }
        
        return None
    
    def _calculate_signal_strength(self, row, direction):
        """
        Calculate signal strength (Potential, Strong, Super)
        
        Args:
            row (pd.Series): Current candle data
            direction (str): 'buy' or 'sell'
            
        Returns:
            str: Signal strength
        """
        score = 0
        
        # Volume factor (relaxed thresholds)
        if row['volume_ratio'] > 1.5:
            score += 3
        elif row['volume_ratio'] > 1.2:
            score += 2
        elif row['volume_ratio'] > 0.8:
            score += 1
        
        # Trend strength factor (relaxed thresholds)
        if row['adx'] > 20:
            score += 2
        elif row['adx'] > 15:
            score += 1
        
        # Pattern factor
        if direction == 'buy':
            if row['bullish_engulfing']:
                score += 2
            if row['hammer']:
                score += 1
            if row['demand_zone']:
                score += 2
        else:  # sell
            if row['bearish_engulfing']:
                score += 2
            if row['supply_zone']:
                score += 2
        
        # Session factor (optional)
        if row['ny_session'] and row['london_session']:
            score += 2  # Overlap session
        elif row['ny_session'] or row['london_session']:
            score += 1
        
        # RSI factor (relaxed thresholds)
        if direction == 'buy' and row['rsi'] < 45:
            score += 1
        elif direction == 'sell' and row['rsi'] > 55:
            score += 1
        
        # Determine strength (relaxed thresholds)
        if score >= 8:
            return 'Super'
        elif score >= 4:
            return 'Strong'
        else:
            return 'Potential'
    
    def _get_confluence_factors(self, row, direction):
        """
        Get confluence factors for the signal
        
        Args:
            row (pd.Series): Current candle data
            direction (str): 'buy' or 'sell'
            
        Returns:
            list: List of confluence factors
        """
        factors = []
        
        # Volume confluence
        if row['volume_ratio'] > 1.5:
            factors.append('High Volume')
        
        # Trend confluence
        if row['adx'] > 20:
            factors.append('Strong Trend')
        
        # Pattern confluence
        if direction == 'buy':
            if row['bullish_engulfing']:
                factors.append('Bullish Engulfing')
            if row['hammer']:
                factors.append('Hammer Pattern')
            if row['demand_zone']:
                factors.append('Demand Zone')
        else:
            if row['bearish_engulfing']:
                factors.append('Bearish Engulfing')
            if row['supply_zone']:
                factors.append('Supply Zone')
        
        # Session confluence
        if row['ny_session'] and row['london_session']:
            factors.append('Session Overlap')
        elif row['ny_session']:
            factors.append('NY Session')
        elif row['london_session']:
            factors.append('London Session')
        
        return factors
    
    def generate_signals(self, df, order_blocks=None):
        """
        Generate trading signals from feature-engineered data
        
        Args:
            df (pd.DataFrame): Feature-engineered OHLCV data
            order_blocks (dict): Order block zones (optional)
            
        Returns:
            pd.DataFrame: Signals dataframe
        """
        print("Generating signals...")
        
        signals = []
        
        # Find order blocks if not provided
        if order_blocks is None:
            from .feature_engineer import FeatureEngineer
            fe = FeatureEngineer()
            order_blocks = fe.find_order_blocks(df)
        
        # Generate signals for each candle
        for i in range(50, len(df)):  # Start from 50 to ensure indicators are calculated
            row = df.iloc[i]
            
            # Check for buy signal
            buy_signal = self.check_buy_conditions(row, order_blocks)
            if buy_signal:
                signals.append(buy_signal)
                continue  # Don't generate both buy and sell on same candle
            
            # Check for sell signal
            sell_signal = self.check_sell_conditions(row, order_blocks)
            if sell_signal:
                signals.append(sell_signal)
        
        # Convert to dataframe
        if signals:
            signals_df = pd.DataFrame(signals)
            signals_df = signals_df.set_index('timestamp')
            
            # Add risk-reward ratios
            signals_df['rr1'] = signals_df.apply(
                lambda x: calculate_risk_reward_ratios(x['entry_price'], x['stop_loss'], x['tp1'], x['tp2'], x['tp3'])['rr1'], 
                axis=1
            )
            signals_df['rr2'] = signals_df.apply(
                lambda x: calculate_risk_reward_ratios(x['entry_price'], x['stop_loss'], x['tp1'], x['tp2'], x['tp3'])['rr2'], 
                axis=1
            )
            signals_df['rr3'] = signals_df.apply(
                lambda x: calculate_risk_reward_ratios(x['entry_price'], x['stop_loss'], x['tp1'], x['tp2'], x['tp3'])['rr3'], 
                axis=1
            )
            
            print(f"Generated {len(signals_df)} signals")
            return signals_df
        else:
            print("No signals generated")
            return pd.DataFrame()
    
    def filter_signals(self, signals_df, min_strength='Potential'):
        """
        Filter signals by minimum strength
        
        Args:
            signals_df (pd.DataFrame): Signals dataframe
            min_strength (str): Minimum strength ('Potential', 'Strong', 'Super')
            
        Returns:
            pd.DataFrame: Filtered signals
        """
        strength_order = {'Potential': 1, 'Strong': 2, 'Super': 3}
        min_score = strength_order.get(min_strength, 1)
        
        filtered_signals = signals_df[
            signals_df['strength_score'].map(strength_order) >= min_score
        ]
        
        print(f"Filtered to {len(filtered_signals)} signals (min strength: {min_strength})")
        return filtered_signals 