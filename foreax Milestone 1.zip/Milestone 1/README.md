# SOLOTREND X - AI-Based Trading Bot

## 🎯 Project Overview

SOLOTREND X is a confluence-based trading system that generates real-time Buy/Sell signals using advanced technical analysis and rule-based logic. This is **Milestone 1** focusing on signal generation and feature engineering.

**Now supports multiple data providers: Finnhub, Twelve Data, and OANDA!**

## 📋 Strategy Components

### Core Features
- **Order Blocks (OB)**: Support/resistance zone detection
- **Supply and Demand Zones**: Price action-based zone identification
- **Hull Moving Average (HMA)**: Trend filtering with 21 and 50-period HMAs
- **Volume Shifts**: Volume spike detection and analysis
- **Session Filters**: NY and London session-only trading
- **Signal Types**: Potential, Strong, Super Buy/Sell signals
- **Risk Management**: Stop Loss, TP1, TP2, TP3 with configurable RR ratios

### Signal Generation Logic
1. **Trend Filter**: HMA trend direction must align with signal direction
2. **Session Filter**: Only trade during NY or London sessions
3. **Volume Filter**: Volume must be above average (1.2x minimum)
4. **Zone Proximity**: Price must be near valid Supply/Demand or Order Block zones
5. **Pattern Confirmation**: Bullish/Bearish candlestick patterns
6. **Strength Scoring**: Multiple confluence factors determine signal strength

## 🚀 Quick Start

### Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd Trading-Bot
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Twelve Data API is configured!** ✅
   - Your Twelve Data API key is already set up in the code
   - Real forex data access (no government ID required)
   - Ready to use with live forex data

4. **Test your setup**:
```bash
python test_twelvedata.py
```

5. **Run the trading bot** (with real forex data):
```bash
python main.py
```

### Data Provider Options

#### 🎯 **Option 1: Twelve Data (Configured & Ready)** ✅
- ✅ **Real forex data**
- ✅ **No government ID required**
- ✅ **Free tier available**
- ✅ **Immediate use**

#### 🎯 **Option 2: Sample Data (For Testing)**
- ✅ **No setup required**
- ✅ **Realistic forex data**
- ✅ **Perfect for testing strategy**
```bash
export DATA_PROVIDER="sample"
python main.py
```

#### 🎯 **Option 3: OANDA (Requires Verification)**
- ✅ **Professional forex data**
- ❌ **Government ID verification required**
- 🔗 **Setup**: https://www.oanda.com/
```bash
export OANDA_ACCESS_TOKEN="your_token_here"
export DATA_PROVIDER="oanda"
```

#### 🎯 **Option 4: Finnhub (Premium Required)**
- ✅ **Premium forex data**
- 💰 **Paid subscription required**
- 🔗 **Pricing**: https://finnhub.io/pricing

## 📊 Available Instruments

### Forex Pairs
- EUR/USD, GBP/USD, USD/JPY, AUD/USD, NZD/USD
- USD/CHF, USD/CAD, EUR/GBP, EUR/JPY, GBP/JPY
- GBP/CHF, GBP/AUD, AUD/JPY, NZD/JPY, CAD/JPY

### Indices (OANDA only)
- US30 (Dow Jones Industrial Average)
- NAS100 (NASDAQ 100)
- SPX500 (S&P 500)
- GER30 (DAX)

### Commodities (OANDA only)
- XAUUSD (Gold)

## 🔌 Data Providers

### 1. **Finnhub** (Recommended)
- **Free tier**: Available
- **Verification**: No government ID required
- **Symbol format**: `EURUSD` (no slash)
- **Website**: https://finnhub.io/
- **Setup**: Sign up for free API key

### 2. **Twelve Data**
- **Free tier**: Available
- **Verification**: No government ID required
- **Symbol format**: `EUR/USD` (with slash)
- **Website**: https://twelvedata.com/
- **Setup**: Sign up for free API key

### 3. **OANDA**
- **Free tier**: Available
- **Verification**: Government ID required
- **Symbol format**: `EUR_USD` (with underscore)
- **Website**: https://www.oanda.com/
- **Setup**: Requires account verification

## 📊 Features

### 1. Feature Engineering (`FeatureEngineer`)

**Technical Indicators**:
- Hull Moving Average (21, 50 periods)
- RSI, MACD, ADX
- ATR for volatility measurement
- Volume moving averages and ratios

**Pattern Detection**:
- Bullish/Bearish engulfing patterns
- Inside bars, Doji, Hammer patterns
- Supply/Demand zone detection
- Order block identification

**Session Indicators**:
- NY session (8:30 AM - 3:00 PM EST)
- London session (8:00 AM - 4:30 PM GMT)
- Session overlap detection

### 2. Signal Generation (`SignalGenerator`)

**Signal Types**:
- **Potential**: Basic confluence (score 1-4)
- **Strong**: Good confluence (score 5-7)
- **Super**: High confluence (score 8+)

**Confluence Factors**:
- Volume spikes (1-3 points)
- Trend strength (1-2 points)
- Pattern recognition (1-2 points)
- Session timing (1-2 points)
- RSI extremes (1 point)

**Risk Management**:
- Configurable RR ratios (default: 1.5, 2.5, 4.0)
- Dynamic stop loss placement
- Multiple take profit levels

### 3. Backtesting (`Backtester`)

**Performance Metrics**:
- Win rate and profit factor
- Average win/loss
- Maximum drawdown
- TP1/TP2/TP3 hit rates
- Signal strength analysis

**Output Files**:
- Detailed trade log (CSV)
- Equity curve and drawdown charts
- P&L distribution analysis
- Exit reason breakdown

## 📁 Project Structure

```
Trading Bot/
├── solotrend_x/
│   ├── __init__.py          # Package initialization
│   ├── utils.py             # Utility functions
│   ├── feature_engineer.py  # Feature engineering module
│   ├── signal_generator.py  # Signal generation logic
│   └── backtester.py        # Backtesting engine
├── main.py                  # Main execution script
├── config.py                # Configuration settings
├── requirements.txt         # Dependencies
├── app.py                   # Web interface
├── examples/
│   ├── oanda_usage.py       # OANDA examples
│   └── multi_provider_usage.py # Multi-provider examples
├── templates/
│   └── index.html          # Web UI template
└── outputs/                 # Generated files
    ├── signals_log.csv
    ├── backtest_trades.csv
    ├── price_signals.png
    └── backtest_results.png
```

## 🔧 Configuration

### Data Provider Settings
Edit `config.py` to customize:
- Default data provider
- Available trading pairs per provider
- Time intervals
- API credentials

### Trading Parameters
- Risk-reward ratios
- Position sizing
- Session filters
- Technical indicator periods

## 🌐 Web Interface

Start the web interface:
```bash
python app.py
```

Then open: `http://localhost:5000`

## 📈 Data Sources

- **Finnhub API**: Real forex data (free tier available)
- **Twelve Data API**: Real forex data (free tier available)
- **OANDA API**: Real forex data (requires verification)
- **Sample Data**: Generated for testing when no API token is available
- **Custom CSV**: Load your own OHLCV data

## ⚠️ Important Notes

1. **Demo Mode**: If no API token is provided, the bot will use sample data
2. **Provider Selection**: Default provider is Finnhub (easiest to set up)
3. **Risk Warning**: This is for educational purposes. Always test thoroughly before live trading
4. **API Limits**: Each provider has different rate limits. Check their documentation for details

## 🔄 Migration from Binance

This version has been updated from Binance (cryptocurrency) to multiple forex data providers:
- Changed data source from Binance to Finnhub/Twelve Data/OANDA
- Updated symbol format for forex pairs
- Adjusted price precision for forex (5 decimal places)
- Modified commission and slippage rates for forex trading

## 🧪 Testing Different Providers

Run the multi-provider test script:
```bash
python examples/multi_provider_usage.py
```

This will test all available providers and compare their performance.

## 📞 Support

For issues or questions:
1. Check the configuration in `config.py`
2. Ensure your API credentials are properly set up
3. Test with the example scripts in the `examples/` directory
4. Check the provider's documentation for API limits and requirements 