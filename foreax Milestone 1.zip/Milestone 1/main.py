"""
SOLOTREND X - Main Execution Script
Milestone 1: Signal Generation and Feature Engineering

This script demonstrates the complete workflow:
1. Load/Generate sample data
2. Engineer features
3. Generate signals
4. Run backtest
5. Save results and plots
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to prevent popup windows
import matplotlib.pyplot as plt
from oandapyV20 import API
from oandapyV20.endpoints.instruments import InstrumentsCandles
import finnhub
import requests
import sys
import os

# Fix Unicode encoding issues on Windows
if sys.platform.startswith('win'):
    # Set UTF-8 encoding for stdout
    sys.stdout.reconfigure(encoding='utf-8')
    # Set environment variable for matplotlib
    os.environ['PYTHONIOENCODING'] = 'utf-8'

# Import SOLOTREND X modules
from solotrend_x import (
    FeatureEngineer, 
    SignalGenerator, 
    Backtester,
    load_data, 
    save_signals, 
    plot_signals
)

def generate_sample_data(symbol='EUR_USD', days=365, start_date=None):
    """
    Generate sample OHLCV data for testing
    
    Args:
        symbol (str): Symbol name
        days (int): Number of days of data
        start_date (datetime): Start date (default: 1 year ago)
        
    Returns:
        pd.DataFrame: Sample OHLCV data
    """
    if start_date is None:
        start_date = datetime.now() - timedelta(days=days)
    
    # Generate datetime index (hourly data)
    dates = pd.date_range(start=start_date, periods=days*24, freq='H')
    
    # Generate realistic price data with trends and volatility
    np.random.seed(42)  # For reproducible results
    
    # Base price (typical forex prices)
    base_price = 1.1000 if 'EUR_USD' in symbol else 1.2500
    
    # Generate price movements
    returns = np.random.normal(0, 0.001, len(dates))  # 0.1% hourly volatility
    
    # Add some trend
    trend = np.linspace(0, 0.05, len(dates))  # 5% trend over period
    returns += trend / len(dates)
    
    # Add some mean reversion
    for i in range(1, len(returns)):
        returns[i] += -0.1 * returns[i-1]  # Mean reversion
    
    # Calculate prices
    prices = base_price * np.exp(np.cumsum(returns))
    
    # Generate OHLCV data
    data = []
    for i, (date, price) in enumerate(zip(dates, prices)):
        # Add some intraday volatility
        intraday_vol = np.random.normal(0, 0.0005)
        
        open_price = price * (1 + intraday_vol)
        close_price = price * (1 + np.random.normal(0, 0.0003))
        high_price = max(open_price, close_price) * (1 + abs(np.random.normal(0, 0.0002)))
        low_price = min(open_price, close_price) * (1 - abs(np.random.normal(0, 0.0002)))
        
        # Generate volume (higher during price movements)
        base_volume = 1000000
        volume_multiplier = 1 + abs(returns[i]) * 100
        volume = base_volume * volume_multiplier * (1 + np.random.normal(0, 0.3))
        
        data.append({
            'datetime': date,
            'open': round(open_price, 5),
            'high': round(high_price, 5),
            'low': round(low_price, 5),
            'close': round(close_price, 5),
            'volume': round(volume, 0)
        })
    
    df = pd.DataFrame(data)
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime')
    df['symbol'] = symbol
    
    return df

def fetch_finnhub_forex(symbol="EURUSD", interval="1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch forex data from Finnhub API
    
    Args:
        symbol (str): Forex symbol (e.g., 'EURUSD')
        interval (str): Time interval ('1' for 1 minute, '60' for 1 hour, 'D' for daily)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Get Finnhub API key (use user's key if no environment variable)
        api_key = os.getenv('FINNHUB_API_KEY', 'd2afda1r01qoad6pkllgd2afda1r01qoad6pklm0')
        
        if not api_key:
            print("Warning: FINNHUB_API_KEY not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        # Initialize Finnhub client
        finnhub_client = finnhub.Client(api_key=api_key)
        
        # Convert dates to timestamps
        start_timestamp = int(datetime.strptime(start_str, "%Y-%m-%d").timestamp())
        end_timestamp = int(datetime.strptime(end_str, "%Y-%m-%d").timestamp())
        
        print(f"Attempting to fetch {symbol} data from Finnhub...")
        
        # Try to fetch forex data
        try:
            data = finnhub_client.forex_candles(symbol, interval, start_timestamp, end_timestamp)
            
            if data['s'] == 'ok' and len(data['t']) > 0:
                # Process the data
                df = pd.DataFrame({
                    'datetime': pd.to_datetime(data['t'], unit='s'),
                    'open': data['o'],
                    'high': data['h'],
                    'low': data['l'],
                    'close': data['c'],
                    'volume': data['v'] if 'v' in data else [1000000] * len(data['t'])
                })
                
                df = df.set_index('datetime')
                df['symbol'] = symbol
                
                print(f"✅ Successfully fetched {len(df)} candles for {symbol} from Finnhub")
                print(f"   Date range: {df.index[0]} to {df.index[-1]}")
                
                return df
            else:
                print(f"❌ No data returned from Finnhub for {symbol}")
                print(f"   Response: {data}")
                return generate_sample_data(symbol, days=30)
                
        except Exception as forex_error:
            print(f"❌ Forex data access error: {forex_error}")
            print("   This usually means forex data is not available in the free tier.")
            print("   Trying alternative data sources...")
            
            # Try to get stock data as a test (to verify API key works)
            try:
                # Test with a stock symbol to verify API key works
                test_data = finnhub_client.quote('AAPL')
                if test_data:
                    print("✅ API key is valid, but forex data requires premium subscription.")
                    print("   Using sample data for forex trading...")
                else:
                    print("❌ API key may be invalid or expired.")
            except Exception as test_error:
                print(f"❌ API key test failed: {test_error}")
            
            return generate_sample_data(symbol, days=30)
            
    except Exception as e:
        print(f"❌ Error fetching data from Finnhub: {e}")
        print("   Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def fetch_twelvedata_forex(symbol="EUR/USD", interval="1h", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch forex data from Twelve Data API
    
    Args:
        symbol (str): Forex symbol (e.g., 'EUR/USD')
        interval (str): Time interval ('1h' for 1 hour, '1d' for daily)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Get Twelve Data API key (use user's key if no environment variable)
        api_key = os.getenv('TWELVEDATA_API_KEY', '85d5c52f7c4d49aa83373de0a83a8f5e')
        
        if not api_key:
            print("Warning: TWELVEDATA_API_KEY not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        # Twelve Data API endpoint
        url = "https://api.twelvedata.com/time_series"
        
        params = {
            "symbol": symbol,
            "interval": interval,
            "start_date": start_str,
            "end_date": end_str,
            "apikey": api_key,
            "format": "JSON"
        }
        
        print(f"Fetching {symbol} data from Twelve Data...")
        
        # Make API request
        response = requests.get(url, params=params)
        data = response.json()
        
        if 'values' in data and data['values']:
            # Process the data
            df_data = []
            for candle in data['values']:
                df_data.append({
                    'datetime': pd.to_datetime(candle['datetime']),
                    'open': float(candle['open']),
                    'high': float(candle['high']),
                    'low': float(candle['low']),
                    'close': float(candle['close']),
                    'volume': float(candle['volume']) if 'volume' in candle else 1000000
                })
            
            df = pd.DataFrame(df_data)
            df = df.set_index('datetime')
            df['symbol'] = symbol
            
            print(f"✅ Successfully fetched {len(df)} candles for {symbol} from Twelve Data")
            print(f"   Date range: {df.index[0]} to {df.index[-1]}")
            print(f"   Price range: {df['low'].min():.5f} - {df['high'].max():.5f}")
            
            return df
        else:
            print(f"❌ No data returned from Twelve Data for {symbol}")
            print(f"   Response: {data}")
            return generate_sample_data(symbol, days=30)
            
    except Exception as e:
        print(f"❌ Error fetching data from Twelve Data: {e}")
        print("   Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def fetch_oanda_ohlcv(symbol="EUR_USD", interval="H1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch OHLCV data from OANDA API
    
    Args:
        symbol (str): OANDA instrument symbol (e.g., 'EUR_USD')
        interval (str): Time interval ('H1' for 1 hour)
        start_str (str): Start date in 'YYYY-MM-DD' format
        end_str (str): End date in 'YYYY-MM-DD' format
        
    Returns:
        pd.DataFrame: OHLCV data with datetime index
    """
    try:
        # Initialize OANDA API (you'll need to set your access token)
        # For demo purposes, we'll use sample data if no token is available
        access_token = os.getenv('OANDA_ACCESS_TOKEN')
        
        if not access_token:
            print("Warning: OANDA_ACCESS_TOKEN not found. Using sample data instead.")
            return generate_sample_data(symbol, days=30)
        
        api = API(access_token=access_token)
        
        # Set up parameters for the API request
        params = {
            "count": 5000,
            "granularity": interval,
            "from": start_str,
            "to": end_str
        }
        
        # Make the API request
        r = InstrumentsCandles(instrument=symbol, params=params)
        api.request(r)
        
        # Process the response
        data = []
        for candle in r.response['candles']:
            data.append({
                'datetime': pd.to_datetime(candle['time']),
                'open': float(candle['mid']['o']),
                'high': float(candle['mid']['h']),
                'low': float(candle['mid']['l']),
                'close': float(candle['mid']['c']),
                'volume': float(candle['volume']) if 'volume' in candle else 1000000
            })
        
        df = pd.DataFrame(data)
        df = df.set_index('datetime')
        df['symbol'] = symbol
        
        print(f"Fetched {len(df)} candles for {symbol} from OANDA")
        print(f"Date range: {df.index[0]} to {df.index[-1]}")
        
        return df
        
    except Exception as e:
        print(f"Error fetching data from OANDA: {e}")
        print("Using sample data instead...")
        return generate_sample_data(symbol, days=30)

def fetch_data(provider="finnhub", symbol="EURUSD", interval="1", start_str="2025-01-01", end_str="2025-07-13"):
    """
    Fetch data from the specified provider
    
    Args:
        provider (str): Data provider ('finnhub', 'twelvedata', 'oanda', 'sample')
        symbol (str): Trading symbol
        interval (str): Time interval
        start_str (str): Start date
        end_str (str): End date
        
    Returns:
        pd.DataFrame: OHLCV data
    """
    print(f"Fetching data from {provider.upper()}...")
    
    if provider.lower() == "finnhub":
        return fetch_finnhub_forex(symbol, interval, start_str, end_str)
    elif provider.lower() == "twelvedata":
        return fetch_twelvedata_forex(symbol, interval, start_str, end_str)
    elif provider.lower() == "oanda":
        return fetch_oanda_ohlcv(symbol, interval, start_str, end_str)
    elif provider.lower() == "sample":
        return generate_sample_data(symbol, days=30)
    else:
        print(f"Unknown provider: {provider}. Using sample data instead.")
        return generate_sample_data(symbol, days=30)

def main():
    """
    Main execution function
    """
    print("SOLOTREND X - Milestone 1")
    print("="*50)
    
    # Step 1: Load or generate data
    print("\nStep 1: Loading Data")
    print("-" * 30)

    # Choose your data provider (twelvedata, finnhub, oanda, or sample)
    data_provider = os.getenv('DATA_PROVIDER', 'twelvedata')  # Default to Twelve Data
    
    # Get trading symbol from environment variable (set by web interface)
    trading_symbol = os.getenv('TRADING_SYMBOL', 'EUR/USD')
    
    # Fetch data from the chosen provider
    df = fetch_data(
        provider=data_provider,
        symbol=trading_symbol,
        interval="1h" if data_provider == "twelvedata" else "60",
        start_str="2025-01-01",
        end_str="2025-07-13"
    )
    
    # Step 2: Feature Engineering
    print("\nStep 2: Feature Engineering")
    print("-" * 30)
    
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    # Step 3: Signal Generation
    print("\nStep 3: Signal Generation")
    print("-" * 30)
    
    sg = SignalGenerator(risk_reward_ratios=[0.7, 0.9, 1.1])
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        # Filter signals by minimum strength
        strong_signals = sg.filter_signals(signals_df, min_strength='Super')
        
        print(f"\nSignal Summary:")
        print(f"Total signals: {len(signals_df)}")
        print(f"Strong+ signals: {len(strong_signals)}")
        
        # Display sample signals
        print(f"\nSample signals:")
        print(signals_df[['signal_type', 'entry_price', 'stop_loss', 'tp1', 'strength_score']].head())
        
        # Step 4: Backtesting
        print("\nStep 4: Backtesting")
        print("-" * 30)
        
        bt = Backtester(initial_capital=10000)
        results = bt.run_backtest(df_features, signals_df, position_size=0.02)
        
        if results:
            # Print results
            bt.print_results(results)
            
            # Step 5: Save Results
            print("\nStep 5: Saving Results")
            print("-" * 30)
            
            # Save signals to CSV
            save_signals(signals_df, 'outputs/signals_log.csv')
            
            # Save strong signals separately
            if len(strong_signals) > 0:
                save_signals(strong_signals, 'outputs/super_signals.csv')
            
            # Save backtest results
            if 'trades_df' in results:
                results['trades_df'].to_csv('outputs/backtest_trades.csv')
            
            # Step 6: Visualization
            print("\nStep 6: Visualization")
            print("-" * 30)
            
            # Plot price action with signals
            plot_signals(df_features, signals_df, 'outputs/price_signals.png')
            
            # Plot backtest results
            bt.plot_results(results, 'outputs/backtest_results.png')
            
            print("\nSOLOTREND X Milestone 1 completed successfully!")
            print("\nOutput files saved in 'outputs/' directory:")
            print("  - signals_log.csv: All generated signals")
            print("  - super_signals.csv: Strong and Super signals only")
            print("  - backtest_trades.csv: Detailed trade log")
            print("  - price_signals.png: Price chart with signals")
            print("  - backtest_results.png: Backtest performance charts")
            
    else:
        print("No signals generated. Check your data and parameters.")

def run_with_custom_data(file_path, symbol='BTCUSD'):
    """
    Run SOLOTREND X with custom data file
    
    Args:
        file_path (str): Path to CSV file
        symbol (str): Symbol name
    """
    print(f"Running SOLOTREND X with custom data: {file_path}")
    print("="*50)
    
    # Load data
    df = load_data(file_path, symbol)
    if df is None:
        print(f"Failed to load data from {file_path}")
        return
    
    # Run the complete pipeline
    fe = FeatureEngineer()
    df_features = fe.engineer_features(df)
    
    sg = SignalGenerator()
    signals_df = sg.generate_signals(df_features)
    
    if len(signals_df) > 0:
        bt = Backtester()
        results = bt.run_backtest(df_features, signals_df)
        
        if results:
            bt.print_results(results)
            save_signals(signals_df, f'outputs/{symbol}_signals.csv')
            plot_signals(df_features, signals_df, f'outputs/{symbol}_chart.png')
            bt.plot_results(results, f'outputs/{symbol}_backtest.png')
    else:
        print("No signals generated from custom data")

if __name__ == "__main__":
    # Create outputs directory
    import os
    os.makedirs('outputs', exist_ok=True)
    
    # Run main function
    main()
    
    # Example of running with custom data (uncomment if you have data)
    # run_with_custom_data('path/to/your/data.csv', 'BTCUSD') 