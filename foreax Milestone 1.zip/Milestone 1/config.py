"""
Configuration file for SOLOTREND X
Contains all adjustable parameters for the trading bot
"""

# =============================================================================
# DATA PROVIDER CONFIGURATION
# =============================================================================

# Available Data Providers (choose one)
DATA_PROVIDERS = {
    "finnhub": {
        "name": "Finnhub",
        "description": "Free tier available, no government ID required",
        "website": "https://finnhub.io/",
        "symbol_format": "EURUSD",  # No slash
        "intervals": {"1m": "1", "5m": "5", "15m": "15", "30m": "30", "1h": "60", "1d": "D"}
    },
    "twelvedata": {
        "name": "Twelve Data",
        "description": "Free tier available, no government ID required",
        "website": "https://twelvedata.com/",
        "symbol_format": "EUR/USD",  # With slash
        "intervals": {"1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1h", "1d": "1day"}
    },
    "oanda": {
        "name": "OANDA",
        "description": "Requires government ID verification",
        "website": "https://www.oanda.com/",
        "symbol_format": "EUR_USD",  # With underscore
        "intervals": {"1m": "M1", "5m": "M5", "15m": "M15", "30m": "M30", "1h": "H1", "1d": "D"}
    }
}

# Default data provider (change this to your preferred provider)
DEFAULT_DATA_PROVIDER = "finnhub"

# API Keys (set these as environment variables)
# FINNHUB_API_KEY = "d2afda1r01qoad6pkllgd2afda1r01qoad6pklm0"  # User's Finnhub key
# TWELVEDATA_API_KEY = "85d5c52f7c4d49aa83373de0a83a8f5e"  # User's Twelve Data key
# OANDA_ACCESS_TOKEN = "your_oanda_access_token"

# =============================================================================
# AVAILABLE INSTRUMENTS BY PROVIDER
# =============================================================================

# Finnhub available pairs
FINNHUB_PAIRS = [
    "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "NZDUSD",
    "USDCHF", "USDCAD", "EURGBP", "EURJPY", "GBPJPY",
    "GBPCHF", "GBPAUD", "AUDJPY", "NZDJPY", "CADJPY"
]

# Twelve Data available pairs
TWELVEDATA_PAIRS = [
    "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "NZD/USD",
    "USD/CHF", "USD/CAD", "EUR/GBP", "EUR/JPY", "GBP/JPY",
    "GBP/CHF", "GBP/AUD", "AUD/JPY", "NZD/JPY", "CAD/JPY"
]

# OANDA available pairs
OANDA_PAIRS = [
    "EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "NZD_USD",
    "USD_CHF", "USD_CAD", "EUR_GBP", "EUR_JPY", "GBP_JPY",
    "GBP_CHF", "GBP_AUD", "US30", "NAS100", "SPX500",
    "GER30", "XAUUSD", "AUD_JPY", "NZD_JPY", "CAD_JPY"
]

# Default symbol for each provider
DEFAULT_SYMBOLS = {
    "finnhub": "EURUSD",
    "twelvedata": "EUR/USD", 
    "oanda": "EUR_USD"
}

# =============================================================================
# SIGNAL GENERATION PARAMETERS
# =============================================================================

# Risk-Reward ratios for Take Profit levels
RISK_REWARD_RATIOS = [1.5, 2.5, 4.0]  # [TP1, TP2, TP3]

# Volume conditions
MIN_VOLUME_RATIO = 1.2  # Minimum volume ratio for signal generation
VOLUME_SPIKE_THRESHOLD = 2.0  # Multiplier for volume spike detection

# Price proximity to zones (as percentage)
ZONE_PROXIMITY = 0.01  # 1% proximity to support/resistance zones
STOP_LOSS_DISTANCE = 0.005  # 0.5% distance from zone for stop loss

# Session trading
ENABLE_SESSION_FILTER = True  # Only trade during NY/London sessions
ENABLE_SESSION_OVERLAP_BONUS = True  # Extra points for session overlap

# =============================================================================
# FEATURE ENGINEERING PARAMETERS
# =============================================================================

# Hull Moving Average periods
HMA_SHORT_PERIOD = 21
HMA_LONG_PERIOD = 50

# Technical indicators
RSI_PERIOD = 14
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
ADX_PERIOD = 14
ATR_PERIOD = 14

# Volume analysis
VOLUME_MA_PERIOD = 20
VOLUME_STD_PERIOD = 20

# Order block detection
ORDER_BLOCK_MIN_TOUCHES = 3
ORDER_BLOCK_TOLERANCE = 0.002  # 0.2% price tolerance

# Supply/Demand zone detection
SUPPLY_DEMAND_WINDOW = 20
SUPPLY_DEMAND_VOLUME_MULTIPLIER = 1.5

# =============================================================================
# SIGNAL STRENGTH SCORING
# =============================================================================

# Volume scoring
VOLUME_SCORE_LEVELS = {
    'high': (2.0, 3),      # Volume > 2x average = 3 points
    'medium': (1.5, 2),    # Volume > 1.5x average = 2 points
    'low': (1.2, 1)        # Volume > 1.2x average = 1 point
}

# Trend strength scoring
TREND_STRENGTH_SCORE_LEVELS = {
    'very_strong': (25, 2),  # ADX > 25 = 2 points
    'strong': (20, 1)        # ADX > 20 = 1 point
}

# Pattern scoring
PATTERN_SCORES = {
    'bullish_engulfing': 2,
    'bearish_engulfing': 2,
    'hammer': 1,
    'demand_zone': 2,
    'supply_zone': 2
}

# Session scoring
SESSION_SCORES = {
    'overlap': 2,    # NY + London overlap
    'single': 1      # Single session active
}

# RSI scoring
RSI_SCORE_LEVELS = {
    'oversold': (30, 1),   # RSI < 30 for buy signals
    'overbought': (70, 1)  # RSI > 70 for sell signals
}

# Signal strength thresholds
SIGNAL_STRENGTH_THRESHOLDS = {
    'Super': 8,      # Score >= 8
    'Strong': 5,     # Score >= 5
    'Potential': 1   # Score >= 1
}

# =============================================================================
# BACKTESTING PARAMETERS
# =============================================================================

# Capital and position sizing
INITIAL_CAPITAL = 10000
POSITION_SIZE = 0.02  # 2% risk per trade
MAX_POSITIONS = 3     # Maximum concurrent positions

# Commission and slippage (forex-specific)
COMMISSION_RATE = 0.0001  # 0.01% commission (typical for forex)
SLIPPAGE_RATE = 0.0002   # 0.02% slippage (typical for forex)

# =============================================================================
# SESSION TIMES (UTC)
# =============================================================================

# New York Session (EST = UTC-5, EDT = UTC-4)
NY_SESSION = {
    'open': '13:30',   # 8:30 AM EST
    'close': '20:00'   # 3:00 PM EST
}

# London Session (GMT = UTC)
LONDON_SESSION = {
    'open': '08:00',   # 8:00 AM GMT
    'close': '16:30'   # 4:30 PM GMT
}

# =============================================================================
# DATA PROCESSING PARAMETERS
# =============================================================================

# Data validation
MIN_DATA_POINTS = 100  # Minimum data points required
MAX_MISSING_VALUES = 0.1

# Feature engineering
LOOKBACK_PERIOD = 50  # Period for rolling calculations
FILL_METHOD = 'ffill'  # Method for filling missing values

# =============================================================================
# OUTPUT AND LOGGING
# =============================================================================

# Output directories
OUTPUT_DIR = 'outputs'
LOG_DIR = 'logs'

# File naming
SIGNALS_FILE = 'signals_log.csv'
STRONG_SIGNALS_FILE = 'strong_signals.csv'
BACKTEST_FILE = 'backtest_trades.csv'
PERFORMANCE_FILE = 'performance_summary.csv'

# Plot settings
PLOT_STYLE = 'seaborn-v0_8'
FIGURE_SIZE = (15, 10)
DPI = 300

# =============================================================================
# VALIDATION PARAMETERS
# =============================================================================

# Signal validation
MIN_SIGNAL_INTERVAL = 4  # Minimum hours between signals
MAX_SIGNALS_PER_DAY = 5  # Maximum signals per day

# Risk management
MAX_DAILY_LOSS = 0.05  # Maximum 5% daily loss
MAX_DRAWDOWN = 0.20    # Maximum 20% drawdown

# =============================================================================
# ADVANCED PARAMETERS
# =============================================================================

# Machine learning (for future use)
ENABLE_ML_FEATURES = False
ML_MODEL_TYPE = 'random_forest'
ML_TRAINING_SPLIT = 0.8

# Real-time settings (for future use)
REALTIME_UPDATE_INTERVAL = 60  # Seconds
WEBSOCKET_ENABLED = False
TELEGRAM_BOT_ENABLED = False

# =============================================================================
# VALIDATION FUNCTIONS
# =============================================================================

def validate_config():
    """Validate configuration parameters"""
    errors = []
    
    # Check risk-reward ratios
    if len(RISK_REWARD_RATIOS) != 3:
        errors.append("RISK_REWARD_RATIOS must have exactly 3 values")
    
    if any(rr <= 0 for rr in RISK_REWARD_RATIOS):
        errors.append("All risk-reward ratios must be positive")
    
    # Check volume parameters
    if MIN_VOLUME_RATIO <= 0:
        errors.append("MIN_VOLUME_RATIO must be positive")
    
    if VOLUME_SPIKE_THRESHOLD <= 0:
        errors.append("VOLUME_SPIKE_THRESHOLD must be positive")
    
    # Check proximity parameters
    if ZONE_PROXIMITY <= 0 or ZONE_PROXIMITY > 0.1:
        errors.append("ZONE_PROXIMITY must be between 0 and 0.1 (10%)")
    
    if STOP_LOSS_DISTANCE <= 0 or STOP_LOSS_DISTANCE > 0.1:
        errors.append("STOP_LOSS_DISTANCE must be between 0 and 0.1 (10%)")
    
    # Check position sizing
    if POSITION_SIZE <= 0 or POSITION_SIZE > 0.1:
        errors.append("POSITION_SIZE must be between 0 and 0.1 (10%)")
    
    if INITIAL_CAPITAL <= 0:
        errors.append("INITIAL_CAPITAL must be positive")
    
    if errors:
        raise ValueError("Configuration validation failed:\n" + "\n".join(errors))
    
    return True

# Validate configuration on import
if __name__ != "__main__":
    try:
        validate_config()
        print("✅ Configuration validated successfully")
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        raise 